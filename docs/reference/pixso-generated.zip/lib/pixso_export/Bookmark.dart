import 'package:flutter/material.dart';
import 'package:flutter_ui/utils/pix_adapted_screen.dart';
import 'package:flutter_ui/components/Group.dart';
import 'package:flutter_ui/utils/pix_flutter_interface.dart';

class Bookmark extends StatefulWidget {

  Bookmark({super.key,});
  @override
  State<Bookmark> createState() => _BookmarkState();
}

class _BookmarkState extends State<Bookmark> {


  @override
  void initState() {
    super.initState();
  
  }


  @override
  Widget build(BuildContext context) {
    ScreenUtil().rootSize = Size(375, 667);
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: MediaQuery.removePadding(
        context: context,
        removeTop: true,
        removeBottom: true,
        child: SizedBox(
            width: 375.w,
            height: 667.h,
            child: ListView(
              children: [
                Container(
                width: 375.w,
                height: 667.h,
                decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                clipBehavior: Clip.hardEdge,
                child: Stack(
                  key: ValueKey("36:37"),
                  children: [
                    Positioned(
                      width: 375.w,
                      height: 152.h,
                      left: 0.w,
                      top: 520.h,
                      child: Container(
                        key: ValueKey("94:23"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, 0.w),blurRadius: 5.w,)],),),),
                    Positioned(
                      width: 375.w,
                      height: 152.h,
                      left: 0.w,
                      top: 368.h,
                      child: Container(
                        key: ValueKey("94:24"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, 0.w),blurRadius: 5.w,)],),),),
                    Positioned(
                      width: 375.w,
                      height: 152.h,
                      left: 0.w,
                      top: 216.h,
                      child: Container(
                        key: ValueKey("94:17"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, 0.w),blurRadius: 5.w,)],),),),
                    Positioned(
                      width: 375.w,
                      height: 64.h,
                      left: 0.w,
                      top: 0.h,
                      child: Container(
                        key: ValueKey("36:38"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, -1.w),blurRadius: 10.w,)],),),),
                    Positioned(
                      width: 116.w,
                      height: 23.h,
                      left: 130.w,
                      top: 29.h,
                      child: Text("Steven Curran",
                        key: ValueKey("36:39"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 17.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 72.w,
                      height: 112.h,
                      left: 16.w,
                      top: 84.h,
                      child: Container(
                        clipBehavior: Clip.hardEdge,
                        decoration: BoxDecoration(),
                        child: Image(
                          key: ValueKey("36:68"),
                          image: AssetImage("http://localhost:3667/assets/1793182110309/MaskGroup.png.png"),),),),
                    Positioned(
                      width: 144.w,
                      height: 18.h,
                      left: 104.w,
                      top: 114.h,
                      child: Text("Motion Design for Film",
                        key: ValueKey("36:71"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.2857142857142858, letterSpacing: 0.w),),),
                    Positioned(
                      width: 94.w,
                      height: 16.h,
                      left: 104.w,
                      top: 136.h,
                      child: Text("by Steven Curran",
                        key: ValueKey("36:72"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(167, 167, 177,1), fontFamily: "Circular Std", fontSize: 11.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 104.w,
                      top: 96.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("36:194"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("36:195"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group40.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 118.w,
                      top: 96.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("36:197"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("36:198"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group39.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 132.w,
                      top: 96.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("36:200"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("36:201"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group42.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 146.w,
                      top: 96.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("36:203"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("36:204"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group41.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 160.w,
                      top: 96.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("36:206"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("36:207"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group38.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 42.w,
                      height: 18.h,
                      left: 317.w,
                      top: 93.h,
                      child: Text("\$10.55",
                        key: ValueKey("36:75"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(50, 205, 119,1), fontFamily: "Circular Std", fontWeight: FontWeight.bold, fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 72.w,
                      height: 112.h,
                      left: 16.w,
                      top: 236.h,
                      child: Container(
                        clipBehavior: Clip.hardEdge,
                        decoration: BoxDecoration(),
                        child: Image(
                          key: ValueKey("36:210"),
                          image: AssetImage("http://localhost:3667/assets/1793182110309/MaskGroup.png.png"),),),),
                    Positioned(
                      width: 114.w,
                      height: 18.h,
                      left: 104.w,
                      top: 266.h,
                      child: Text("How to Stop Time",
                        key: ValueKey("36:213"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.2857142857142858, letterSpacing: 0.w),),),
                    Positioned(
                      width: 94.w,
                      height: 16.h,
                      left: 104.w,
                      top: 288.h,
                      child: Text("by Steven Curran",
                        key: ValueKey("36:214"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(167, 167, 177,1), fontFamily: "Circular Std", fontSize: 11.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 104.w,
                      top: 248.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("36:215"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("36:216"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group37.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 118.w,
                      top: 248.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("36:218"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("36:219"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group36.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 132.w,
                      top: 248.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("36:221"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("36:222"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group35.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 146.w,
                      top: 248.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("36:224"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("36:225"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group34.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 160.w,
                      top: 248.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("36:227"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("36:228"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group33.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 41.w,
                      height: 18.h,
                      left: 318.w,
                      top: 245.h,
                      child: Text("\$20.12",
                        key: ValueKey("36:230"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(50, 205, 119,1), fontFamily: "Circular Std", fontWeight: FontWeight.bold, fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 72.w,
                      height: 112.h,
                      left: 16.w,
                      top: 388.h,
                      child: Container(
                        clipBehavior: Clip.hardEdge,
                        decoration: BoxDecoration(),
                        child: Image(
                          key: ValueKey("94:25"),
                          image: AssetImage("http://localhost:3667/assets/1793182110309/MaskGroup.png.png"),),),),
                    Positioned(
                      width: 140.w,
                      height: 18.h,
                      left: 104.w,
                      top: 418.h,
                      child: Text("Hardwiring Happiness",
                        key: ValueKey("94:29"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.2857142857142858, letterSpacing: 0.w),),),
                    Positioned(
                      width: 94.w,
                      height: 16.h,
                      left: 104.w,
                      top: 440.h,
                      child: Text("by Steven Curran",
                        key: ValueKey("94:30"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(167, 167, 177,1), fontFamily: "Circular Std", fontSize: 11.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 104.w,
                      top: 400.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("94:31"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("94:32"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group32.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 118.w,
                      top: 400.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("94:34"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("94:35"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group31.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 132.w,
                      top: 400.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("94:37"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("94:38"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group30.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 146.w,
                      top: 400.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("94:40"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("94:41"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group29.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 160.w,
                      top: 400.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("94:43"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("94:44"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group28.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 39.w,
                      height: 18.h,
                      left: 320.w,
                      top: 397.h,
                      child: Text("\$17.25",
                        key: ValueKey("94:46"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(50, 205, 119,1), fontFamily: "Circular Std", fontWeight: FontWeight.bold, fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 72.w,
                      height: 112.h,
                      left: 16.w,
                      top: 540.h,
                      child: Container(
                        clipBehavior: Clip.hardEdge,
                        decoration: BoxDecoration(),
                        child: Image(
                          key: ValueKey("94:48"),
                          image: AssetImage("http://localhost:3667/assets/1793182110309/MaskGroup.png.png"),),),),
                    Positioned(
                      width: 114.w,
                      height: 18.h,
                      left: 104.w,
                      top: 570.h,
                      child: Text("How to Stop Time",
                        key: ValueKey("94:52"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.2857142857142858, letterSpacing: 0.w),),),
                    Positioned(
                      width: 94.w,
                      height: 16.h,
                      left: 104.w,
                      top: 592.h,
                      child: Text("by Steven Curran",
                        key: ValueKey("94:53"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(167, 167, 177,1), fontFamily: "Circular Std", fontSize: 11.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 104.w,
                      top: 552.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("94:54"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("94:55"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group27.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 118.w,
                      top: 552.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("94:57"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("94:58"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group26.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 132.w,
                      top: 552.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("94:60"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("94:61"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group25.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 146.w,
                      top: 552.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("94:63"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("94:64"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group24.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 160.w,
                      top: 552.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("94:66"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("94:67"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group23.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 44.w,
                      height: 18.h,
                      left: 316.w,
                      top: 549.h,
                      child: Text("\$24.70 ",
                        key: ValueKey("94:69"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(50, 205, 119,1), fontFamily: "Circular Std", fontWeight: FontWeight.bold, fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 18.w,
                      height: 18.h,
                      left: 341.w,
                      top: 31.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("36:143"),
                          children: [
                            Positioned(
                              width: 19.71.w,
                              height: 19.71.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("36:144"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group22.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 12.01.w,
                      height: 20.h,
                      left: 15.38.w,
                      top: 30.h,
                      child: Image(
                        key: ValueKey("38:52"),
                        image: AssetImage("http://localhost:3667/assets/1793182110309/BackArrowStroke2.svg.png"),),),
                    Group({"6:525":PixFlutterInterface(width:31.w,height:16.h,left:304.5.w,top:0.h,),"6:526":PixFlutterInterface(width:24.5.w,height:9.5.h,left:338.5.w,top:3.5.h,),"6:527":PixFlutterInterface(width:22.5.w,height:9.5.h,left:0.w,top:0.h,),"6:528":PixFlutterInterface(width:22.5.w,height:9.5.h,left:0.w,top:0.h,),"6:529":PixFlutterInterface(width:21.5.w,height:8.5.h,left:0.5.w,top:0.5.h,),"6:530":PixFlutterInterface(width:22.5.w,height:9.5.h,left:0.w,top:0.h,),"6:531":PixFlutterInterface(width:20.5.w,height:7.5.h,left:1.w,top:1.h,),"6:532":PixFlutterInterface(width:1.5.w,height:3.5.h,left:23.w,top:3.h,),"6:542":PixFlutterInterface(width:48.w,height:16.h,left:157.w,top:1.h,),"6:543":PixFlutterInterface(width:33.5.w,height:5.5.h,left:0.w,top:5.5.h,),"6:544":PixFlutterInterface(width:5.5.w,height:5.5.w,left:28.w,top:0.h,),"6:545":PixFlutterInterface(width:4.5.w,height:4.5.w,left:0.5.w,top:0.5.h,),"6:546":PixFlutterInterface(width:5.5.w,height:5.5.w,left:0.w,top:0.h,),"6:547":PixFlutterInterface(width:5.5.w,height:5.5.w,left:21.w,top:0.h,),"6:548":PixFlutterInterface(width:5.5.w,height:5.5.w,left:14.w,top:0.h,),"6:549":PixFlutterInterface(width:5.5.w,height:5.5.w,left:7.w,top:0.h,),"6:550":PixFlutterInterface(width:5.5.w,height:5.5.w,left:0.w,top:0.h,),"96:52":PixFlutterInterface(width:363.w,height:17.h,left:6.5.w,top:2.h,),}, false),
                  ],),),
              ],
            )
          )
        
      ),
      
      
    );
  }
}
