import 'package:flutter/material.dart';
import 'package:flutter_ui/utils/pix_adapted_screen.dart';

class ListAuthor extends StatefulWidget {

  ListAuthor({super.key,});
  @override
  State<ListAuthor> createState() => _ListAuthorState();
}

class _ListAuthorState extends State<ListAuthor> {


  @override
  void initState() {
    super.initState();
  
  }


  @override
  Widget build(BuildContext context) {
    ScreenUtil().rootSize = Size(375, 667);
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: MediaQuery.removePadding(
        context: context,
        removeTop: true,
        removeBottom: true,
        child: SizedBox(
            width: 375.w,
            height: 667.h,
            child: ListView(
              children: [
                Container(
                width: 375.w,
                height: 667.h,
                decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                clipBehavior: Clip.hardEdge,
                child: Stack(
                  key: ValueKey("6:520"),
                  children: [
                    Positioned(
                      width: 375.w,
                      height: 45.h,
                      left: 0.w,
                      top: 64.h,
                      child: Container(
                        key: ValueKey("95:239"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, 0.w),blurRadius: 5.w,)],),),),
                    Positioned(
                      width: 375.w,
                      height: 45.h,
                      left: 0.w,
                      top: 413.h,
                      child: Container(
                        key: ValueKey("95:240"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, 0.w),blurRadius: 5.w,)],),),),
                    Positioned(
                      width: 375.w,
                      height: 64.h,
                      left: 0.w,
                      top: 0.h,
                      child: Container(
                        key: ValueKey("6:522"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, -1.w),blurRadius: 10.w,)],),),),
                    Positioned(
                      width: 98.w,
                      height: 23.h,
                      left: 139.w,
                      top: 29.h,
                      child: Text("List Authors",
                        key: ValueKey("6:523"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 17.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 98.w,
                      height: 18.h,
                      left: 60.w,
                      top: 132.h,
                      child: Text("Aaron Stephen\t",
                        key: ValueKey("6:601"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.2857142857142858, letterSpacing: 0.w),),),
                    Positioned(
                      width: 17.w,
                      height: 24.h,
                      left: 16.w,
                      top: 75.h,
                      child: Text("A",
                        key: ValueKey("6:709"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 17.6.sp, height: 1, letterSpacing: 0.w),),),
                    Positioned(
                      width: 116.w,
                      height: 24.h,
                      left: 292.w,
                      top: 77.h,
                      child: Text("30 authors",
                        key: ValueKey("45:0"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(167, 167, 177,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.2857142857142858, letterSpacing: 0.w),),),
                    Positioned(
                      width: 32.w,
                      height: 32.h,
                      left: 16.w,
                      top: 125.h,
                      child: Container(
                        clipBehavior: Clip.hardEdge,
                        decoration: BoxDecoration(),
                        child: Image(
                          key: ValueKey("36:165"),
                          image: AssetImage("http://localhost:3667/assets/1793182110309/MaskGroup.png.png"),),),),
                    Positioned(
                      width: 74.w,
                      height: 18.h,
                      left: 60.w,
                      top: 180.h,
                      child: Text("Abel Travis\t",
                        key: ValueKey("6:712"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.2857142857142858, letterSpacing: 0.w),),),
                    Positioned(
                      width: 32.w,
                      height: 32.h,
                      left: 16.w,
                      top: 173.h,
                      child: Container(
                        clipBehavior: Clip.hardEdge,
                        decoration: BoxDecoration(),
                        child: Image(
                          key: ValueKey("36:168"),
                          image: AssetImage("http://localhost:3667/assets/1793182110309/MaskGroup.png.png"),),),),
                    Positioned(
                      width: 90.w,
                      height: 18.h,
                      left: 60.w,
                      top: 228.h,
                      child: Text("Abram Hunter",
                        key: ValueKey("6:714"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.2857142857142858, letterSpacing: 0.w),),),
                    Positioned(
                      width: 32.w,
                      height: 32.h,
                      left: 16.w,
                      top: 221.h,
                      child: Container(
                        clipBehavior: Clip.hardEdge,
                        decoration: BoxDecoration(),
                        child: Image(
                          key: ValueKey("36:171"),
                          image: AssetImage("http://localhost:3667/assets/1793182110309/MaskGroup.png.png"),),),),
                    Positioned(
                      width: 80.w,
                      height: 18.h,
                      left: 60.w,
                      top: 276.h,
                      child: Text("Albert Smith",
                        key: ValueKey("6:716"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.2857142857142858, letterSpacing: 0.w),),),
                    Positioned(
                      width: 32.w,
                      height: 32.h,
                      left: 16.w,
                      top: 269.h,
                      child: Container(
                        clipBehavior: Clip.hardEdge,
                        decoration: BoxDecoration(),
                        child: Image(
                          key: ValueKey("36:174"),
                          image: AssetImage("http://localhost:3667/assets/1793182110309/MaskGroup.png.png"),),),),
                    Positioned(
                      width: 97.w,
                      height: 18.h,
                      left: 60.w,
                      top: 324.h,
                      child: Text("Alexis Fredrick\t",
                        key: ValueKey("36:6"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.2857142857142858, letterSpacing: 0.w),),),
                    Positioned(
                      width: 32.w,
                      height: 32.h,
                      left: 16.w,
                      top: 317.h,
                      child: Container(
                        clipBehavior: Clip.hardEdge,
                        decoration: BoxDecoration(),
                        child: Image(
                          key: ValueKey("36:177"),
                          image: AssetImage("http://localhost:3667/assets/1793182110309/MaskGroup.png.png"),),),),
                    Positioned(
                      width: 113.w,
                      height: 18.h,
                      left: 60.w,
                      top: 372.h,
                      child: Text("Anderson Lindsey",
                        key: ValueKey("36:8"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.2857142857142858, letterSpacing: 0.w),),),
                    Positioned(
                      width: 32.w,
                      height: 32.h,
                      left: 16.w,
                      top: 365.h,
                      child: Container(
                        clipBehavior: Clip.hardEdge,
                        decoration: BoxDecoration(),
                        child: Image(
                          key: ValueKey("36:180"),
                          image: AssetImage("http://localhost:3667/assets/1793182110309/MaskGroup.png.png"),),),),
                    Positioned(
                      width: 92.w,
                      height: 18.h,
                      left: 59.w,
                      top: 481.h,
                      child: Text("Barney Harvey",
                        key: ValueKey("6:718"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.2857142857142858, letterSpacing: 0.w),),),
                    Positioned(
                      width: 32.w,
                      height: 32.h,
                      left: 16.w,
                      top: 474.h,
                      child: Container(
                        clipBehavior: Clip.hardEdge,
                        decoration: BoxDecoration(),
                        child: Image(
                          key: ValueKey("36:183"),
                          image: AssetImage("http://localhost:3667/assets/1793182110309/MaskGroup.png.png"),),),),
                    Positioned(
                      width: 102.w,
                      height: 18.h,
                      left: 59.w,
                      top: 529.h,
                      child: Text("Bennie Freeman",
                        key: ValueKey("6:721"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.2857142857142858, letterSpacing: 0.w),),),
                    Positioned(
                      width: 32.w,
                      height: 32.h,
                      left: 16.w,
                      top: 522.h,
                      child: Container(
                        clipBehavior: Clip.hardEdge,
                        decoration: BoxDecoration(),
                        child: Image(
                          key: ValueKey("36:186"),
                          image: AssetImage("http://localhost:3667/assets/1793182110309/MaskGroup.png.png"),),),),
                    Positioned(
                      width: 90.w,
                      height: 18.h,
                      left: 59.w,
                      top: 577.h,
                      child: Text("Bobby Murray",
                        key: ValueKey("6:723"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.2857142857142858, letterSpacing: 0.w),),),
                    Positioned(
                      width: 32.w,
                      height: 32.h,
                      left: 16.w,
                      top: 570.h,
                      child: Container(
                        clipBehavior: Clip.hardEdge,
                        decoration: BoxDecoration(),
                        child: Image(
                          key: ValueKey("36:189"),
                          image: AssetImage("http://localhost:3667/assets/1793182110309/MaskGroup.png.png"),),),),
                    Positioned(
                      width: 97.w,
                      height: 18.h,
                      left: 59.w,
                      top: 625.h,
                      child: Text("Bradford Harris",
                        key: ValueKey("36:31"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.2857142857142858, letterSpacing: 0.w),),),
                    Positioned(
                      width: 32.w,
                      height: 32.h,
                      left: 16.w,
                      top: 618.h,
                      child: Container(
                        clipBehavior: Clip.hardEdge,
                        decoration: BoxDecoration(),
                        child: Image(
                          key: ValueKey("36:192"),
                          image: AssetImage("http://localhost:3667/assets/1793182110309/MaskGroup.png.png"),),),),
                    Positioned(
                      width: 17.w,
                      height: 24.h,
                      left: 16.w,
                      top: 424.h,
                      child: Text("B",
                        key: ValueKey("36:11"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 17.6.sp, height: 1, letterSpacing: 0.w),),),
                    Positioned(
                      width: 138.w,
                      height: 24.h,
                      left: 296.w,
                      top: 426.h,
                      child: Text("18 authors",
                        key: ValueKey("45:1"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(167, 167, 177,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.2857142857142858, letterSpacing: 0.w),),),
                    Positioned(
                      width: 18.w,
                      height: 18.h,
                      left: 341.w,
                      top: 32.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("36:14"),
                          children: [
                            Positioned(
                              width: 19.71.w,
                              height: 19.71.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("36:15"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group79.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 12.01.w,
                      height: 20.h,
                      left: 15.38.w,
                      top: 30.h,
                      child: Image(
                        key: ValueKey("38:53"),
                        image: AssetImage("http://localhost:3667/assets/1793182110309/BackArrowStroke5.svg.png"),),),
                  ],),),
              ],
            )
          )
        
      ),
      
      
    );
  }
}
