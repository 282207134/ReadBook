import 'package:flutter/material.dart';
import 'package:flutter_ui/utils/pix_adapted_screen.dart';
import 'package:flutter_ui/components/Group.dart';
import 'package:flutter_ui/utils/pix_flutter_interface.dart';

class SignUp extends StatefulWidget {

  SignUp({super.key,});
  @override
  State<SignUp> createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {


  @override
  void initState() {
    super.initState();
  
  }


  @override
  Widget build(BuildContext context) {
    ScreenUtil().rootSize = Size(375, 667);
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: MediaQuery.removePadding(
        context: context,
        removeTop: true,
        removeBottom: true,
        child: SizedBox(
            width: 375.w,
            height: 667.h,
            child: ListView(
              children: [
                Container(
                width: 375.w,
                height: 667.h,
                decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                clipBehavior: Clip.hardEdge,
                child: Stack(
                  key: ValueKey("11:16"),
                  children: [
                    Positioned(
                      width: 375.w,
                      height: 64.h,
                      left: 0.w,
                      top: 0.h,
                      child: Container(
                        key: ValueKey("11:17"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, -1.w),blurRadius: 10.w,)],),),),
                    Positioned(
                      width: 63.w,
                      height: 23.h,
                      left: 156.w,
                      top: 29.h,
                      child: Text("Sign Up",
                        key: ValueKey("11:18"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 17.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 311.w,
                      height: 44.h,
                      left: 32.w,
                      top: 96.h,
                      child: Container(
                        key: ValueKey("34:144"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),borderRadius: BorderRadius.circular(4.h),border: Border.all(width: 1.w, color: Color.fromRGBO(229, 229, 229,1), ),),),),
                    Positioned(
                      width: 64.w,
                      height: 18.h,
                      left: 45.w,
                      top: 109.h,
                      child: Text("Username",
                        key: ValueKey("34:145"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(167, 167, 177,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 311.w,
                      height: 44.h,
                      left: 32.w,
                      top: 156.h,
                      child: Container(
                        key: ValueKey("34:146"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),borderRadius: BorderRadius.circular(4.h),border: Border.all(width: 1.w, color: Color.fromRGBO(229, 229, 229,1), ),),),),
                    Positioned(
                      width: 87.w,
                      height: 18.h,
                      left: 45.w,
                      top: 169.h,
                      child: Text("Email address",
                        key: ValueKey("34:147"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(167, 167, 177,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 311.w,
                      height: 44.h,
                      left: 32.w,
                      top: 216.h,
                      child: Container(
                        key: ValueKey("34:149"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),borderRadius: BorderRadius.circular(4.h),border: Border.all(width: 1.w, color: Color.fromRGBO(229, 229, 229,1), ),),),),
                    Positioned(
                      width: 61.w,
                      height: 18.h,
                      left: 45.w,
                      top: 229.h,
                      child: Text("Password",
                        key: ValueKey("34:150"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(167, 167, 177,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 311.w,
                      height: 44.h,
                      left: 32.w,
                      top: 276.h,
                      child: Container(
                        key: ValueKey("34:151"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),borderRadius: BorderRadius.circular(4.h),border: Border.all(width: 1.w, color: Color.fromRGBO(229, 229, 229,1), ),),),),
                    Positioned(
                      width: 108.w,
                      height: 18.h,
                      left: 45.w,
                      top: 289.h,
                      child: Text("Retype Password",
                        key: ValueKey("34:152"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(167, 167, 177,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 311.w,
                      height: 46.h,
                      left: 32.w,
                      top: 344.h,
                      child: Container(
                        key: ValueKey("34:153"),
                        decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment(0,0), end: Alignment(1.0000000289389066,1.0000000217391303), colors: [Color.fromRGBO(129, 251, 184,1), Color.fromRGBO(40, 199, 111,1)], stops: [0, 1]),borderRadius: BorderRadius.circular(4.h),border: Border.all(width: 1.w, color: Colors.transparent, ),),),),
                    Positioned(
                      width: 55.w,
                      height: 19.h,
                      left: 160.w,
                      top: 358.h,
                      child: Text("Sign Up",
                        key: ValueKey("34:154"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(255, 255, 255,1), fontFamily: "Circular Std", fontWeight: FontWeight.bold, fontSize: 14.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 12.01.w,
                      height: 20.h,
                      left: 15.38.w,
                      top: 30.h,
                      child: Image(
                        key: ValueKey("38:54"),
                        image: AssetImage("http://localhost:3667/assets/1793182110309/BackArrowStroke8.svg.png"),),),
                    Group({"6:525":PixFlutterInterface(textColor:Color.fromRGBO(34, 34, 59,1),width:31.w,height:16.h,left:304.5.w,top:0.h,),"6:526":PixFlutterInterface(backgroundColor:Color.fromRGBO(34, 34, 59,1),width:24.5.w,height:9.5.h,left:338.5.w,top:3.5.h,),"6:542":PixFlutterInterface(textColor:Color.fromRGBO(34, 34, 59,1),width:48.w,height:16.h,left:157.w,top:1.h,),"6:543":PixFlutterInterface(backgroundColor:Color.fromRGBO(34, 34, 59,1),width:33.5.w,height:5.5.h,left:0.w,top:5.5.h,),"96:52":PixFlutterInterface(width:363.w,height:17.h,left:6.5.w,top:2.h,),"6:527":PixFlutterInterface(width:22.5.w,height:9.5.h,left:0.w,top:0.h,),"6:528":PixFlutterInterface(width:22.5.w,height:9.5.h,left:0.w,top:0.h,),"6:529":PixFlutterInterface(width:21.5.w,height:8.5.h,left:0.5.w,top:0.5.h,),"6:530":PixFlutterInterface(width:22.5.w,height:9.5.h,left:0.w,top:0.h,),"6:531":PixFlutterInterface(width:20.5.w,height:7.5.h,left:1.w,top:1.h,),"6:532":PixFlutterInterface(width:1.5.w,height:3.5.h,left:23.w,top:3.h,),"6:544":PixFlutterInterface(width:5.5.w,height:5.5.w,left:28.w,top:0.h,),"6:545":PixFlutterInterface(width:4.5.w,height:4.5.w,left:0.5.w,top:0.5.h,),"6:546":PixFlutterInterface(width:5.5.w,height:5.5.w,left:0.w,top:0.h,),"6:547":PixFlutterInterface(width:5.5.w,height:5.5.w,left:21.w,top:0.h,),"6:548":PixFlutterInterface(width:5.5.w,height:5.5.w,left:14.w,top:0.h,),"6:549":PixFlutterInterface(width:5.5.w,height:5.5.w,left:7.w,top:0.h,),"6:550":PixFlutterInterface(width:5.5.w,height:5.5.w,left:0.w,top:0.h,),}, false),
                  ],),),
              ],
            )
          )
        
      ),
      
      
    );
  }
}
