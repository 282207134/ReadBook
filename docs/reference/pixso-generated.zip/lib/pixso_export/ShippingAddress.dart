import 'package:flutter/material.dart';
import 'package:flutter_ui/utils/pix_adapted_screen.dart';
import 'package:flutter_ui/components/Group.dart';
import 'package:flutter_ui/utils/pix_flutter_interface.dart';

class ShippingAddress extends StatefulWidget {

  ShippingAddress({super.key,});
  @override
  State<ShippingAddress> createState() => _ShippingAddressState();
}

class _ShippingAddressState extends State<ShippingAddress> {


  @override
  void initState() {
    super.initState();
  
  }


  @override
  Widget build(BuildContext context) {
    ScreenUtil().rootSize = Size(375, 812);
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: MediaQuery.removePadding(
        context: context,
        removeTop: true,
        removeBottom: true,
        child: SizedBox(
            width: 375.w,
            height: 812.h,
            child: ListView(
              children: [
                Container(
                width: 375.w,
                height: 897.h,
                decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                clipBehavior: Clip.hardEdge,
                child: Stack(
                  key: ValueKey("6:270"),
                  children: [
                    Positioned(
                      width: 375.w,
                      height: 64.h,
                      left: 0.w,
                      top: 0.h,
                      child: Container(
                        key: ValueKey("6:271"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, -1.w),blurRadius: 10.w,)],),),),
                    Positioned(
                      width: 143.w,
                      height: 23.h,
                      left: 116.w,
                      top: 29.h,
                      child: Text("Shipping Address",
                        key: ValueKey("6:272"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 17.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 69.w,
                      height: 18.h,
                      left: 15.w,
                      top: 84.h,
                      child: Text("First Name",
                        key: ValueKey("6:327"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 343.w,
                      height: 44.h,
                      left: 16.w,
                      top: 110.h,
                      child: Container(
                        key: ValueKey("6:328"),
                        decoration: BoxDecoration(borderRadius: BorderRadius.circular(4.h),border: Border.all(width: 1.w, color: Color.fromRGBO(226, 226, 226,1), ),),),),
                    Positioned(
                      width: 68.w,
                      height: 18.h,
                      left: 15.w,
                      top: 174.h,
                      child: Text("Last Name",
                        key: ValueKey("6:330"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 343.w,
                      height: 44.h,
                      left: 16.w,
                      top: 200.h,
                      child: Container(
                        key: ValueKey("6:331"),
                        decoration: BoxDecoration(borderRadius: BorderRadius.circular(4.h),border: Border.all(width: 1.w, color: Color.fromRGBO(226, 226, 226,1), ),),),),
                    Positioned(
                      width: 82.w,
                      height: 18.h,
                      left: 15.w,
                      top: 264.h,
                      child: Text("Address Line",
                        key: ValueKey("6:332"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 343.w,
                      height: 44.h,
                      left: 16.w,
                      top: 290.h,
                      child: Container(
                        key: ValueKey("6:333"),
                        decoration: BoxDecoration(borderRadius: BorderRadius.circular(4.h),border: Border.all(width: 1.w, color: Color.fromRGBO(226, 226, 226,1), ),),),),
                    Positioned(
                      width: 93.w,
                      height: 18.h,
                      left: 15.w,
                      top: 360.h,
                      child: Text("Address Line 2",
                        key: ValueKey("6:334"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 343.w,
                      height: 44.h,
                      left: 16.w,
                      top: 386.h,
                      child: Container(
                        key: ValueKey("6:335"),
                        decoration: BoxDecoration(borderRadius: BorderRadius.circular(4.h),border: Border.all(width: 1.w, color: Color.fromRGBO(226, 226, 226,1), ),),),),
                    Positioned(
                      width: 52.w,
                      height: 18.h,
                      left: 16.w,
                      top: 450.h,
                      child: Text("Country",
                        key: ValueKey("6:336"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 85.w,
                      height: 18.h,
                      left: 28.w,
                      top: 489.h,
                      child: Text("United States",
                        key: ValueKey("33:151"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 343.w,
                      height: 44.h,
                      left: 16.w,
                      top: 476.h,
                      child: Container(
                        key: ValueKey("6:337"),
                        decoration: BoxDecoration(borderRadius: BorderRadius.circular(4.h),border: Border.all(width: 1.w, color: Color.fromRGBO(226, 226, 226,1), ),),),),
                    Positioned(
                      width: 10.w,
                      height: 7.5.h,
                      left: 337.w,
                      top: 495.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("33:148"),
                          children: [
                            Positioned(
                              width: 10.w,
                              height: 7.5.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("33:149"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group1.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 61.w,
                      height: 18.h,
                      left: 28.w,
                      top: 579.h,
                      child: Text("New York",
                        key: ValueKey("33:152"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 10.w,
                      height: 7.5.h,
                      left: 337.w,
                      top: 585.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("33:153"),
                          children: [
                            Positioned(
                              width: 10.w,
                              height: 7.5.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("33:154"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group0.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 27.w,
                      height: 18.h,
                      left: 16.w,
                      top: 540.h,
                      child: Text("City",
                        key: ValueKey("6:338"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 343.w,
                      height: 44.h,
                      left: 16.w,
                      top: 566.h,
                      child: Container(
                        key: ValueKey("6:339"),
                        decoration: BoxDecoration(borderRadius: BorderRadius.circular(4.h),border: Border.all(width: 1.w, color: Color.fromRGBO(226, 226, 226,1), ),),),),
                    Positioned(
                      width: 94.w,
                      height: 18.h,
                      left: 16.w,
                      top: 637.h,
                      child: Text("State/Province",
                        key: ValueKey("6:340"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 343.w,
                      height: 44.h,
                      left: 16.w,
                      top: 663.h,
                      child: Container(
                        key: ValueKey("6:341"),
                        decoration: BoxDecoration(borderRadius: BorderRadius.circular(4.h),border: Border.all(width: 1.w, color: Color.fromRGBO(226, 226, 226,1), ),),),),
                    Positioned(
                      width: 65.w,
                      height: 18.h,
                      left: 16.w,
                      top: 733.h,
                      child: Text("Post Code",
                        key: ValueKey("6:342"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 343.w,
                      height: 44.h,
                      left: 16.w,
                      top: 759.h,
                      child: Container(
                        key: ValueKey("6:343"),
                        decoration: BoxDecoration(borderRadius: BorderRadius.circular(4.h),border: Border.all(width: 1.w, color: Color.fromRGBO(226, 226, 226,1), ),),),),
                    Positioned(
                      width: 343.w,
                      height: 46.h,
                      left: 16.w,
                      top: 835.h,
                      child: Container(
                        key: ValueKey("6:344"),
                        decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment(0,0), end: Alignment(1.0000000291545188,1.0000000217391303), colors: [Color.fromRGBO(129, 251, 184,1), Color.fromRGBO(40, 199, 111,1)], stops: [0, 1]),borderRadius: BorderRadius.circular(4.h),border: Border.all(width: 1.w, color: Colors.transparent, ),),),),
                    Positioned(
                      width: 65.w,
                      height: 20.h,
                      left: 155.w,
                      top: 848.h,
                      child: Text("Continue",
                        key: ValueKey("6:345"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(255, 255, 255,1), fontFamily: "Circular Std", fontWeight: FontWeight.bold, fontSize: 14.6.sp, height: 1.3333333333333333, letterSpacing: 0.w),),),
                    Positioned(
                      width: 12.01.w,
                      height: 20.h,
                      left: 15.38.w,
                      top: 30.h,
                      child: Image(
                        key: ValueKey("38:49"),
                        image: AssetImage("http://localhost:3667/assets/1793182110309/BackArrowStroke0.svg.png"),),),
                    Group({"6:525":PixFlutterInterface(textColor:Color.fromRGBO(34, 34, 59,1),width:31.w,height:16.h,left:304.5.w,top:0.h,),"6:526":PixFlutterInterface(backgroundColor:Color.fromRGBO(34, 34, 59,1),width:24.5.w,height:9.5.h,left:338.5.w,top:3.5.h,),"6:542":PixFlutterInterface(textColor:Color.fromRGBO(34, 34, 59,1),width:48.w,height:16.h,left:157.w,top:1.h,),"6:543":PixFlutterInterface(backgroundColor:Color.fromRGBO(34, 34, 59,1),width:33.5.w,height:5.5.h,left:0.w,top:5.5.h,),"96:52":PixFlutterInterface(width:363.w,height:17.h,left:6.5.w,top:2.h,),"6:527":PixFlutterInterface(width:22.5.w,height:9.5.h,left:0.w,top:0.h,),"6:528":PixFlutterInterface(width:22.5.w,height:9.5.h,left:0.w,top:0.h,),"6:529":PixFlutterInterface(width:21.5.w,height:8.5.h,left:0.5.w,top:0.5.h,),"6:530":PixFlutterInterface(width:22.5.w,height:9.5.h,left:0.w,top:0.h,),"6:531":PixFlutterInterface(width:20.5.w,height:7.5.h,left:1.w,top:1.h,),"6:532":PixFlutterInterface(width:1.5.w,height:3.5.h,left:23.w,top:3.h,),"6:544":PixFlutterInterface(width:5.5.w,height:5.5.w,left:28.w,top:0.h,),"6:545":PixFlutterInterface(width:4.5.w,height:4.5.w,left:0.5.w,top:0.5.h,),"6:546":PixFlutterInterface(width:5.5.w,height:5.5.w,left:0.w,top:0.h,),"6:547":PixFlutterInterface(width:5.5.w,height:5.5.w,left:21.w,top:0.h,),"6:548":PixFlutterInterface(width:5.5.w,height:5.5.w,left:14.w,top:0.h,),"6:549":PixFlutterInterface(width:5.5.w,height:5.5.w,left:7.w,top:0.h,),"6:550":PixFlutterInterface(width:5.5.w,height:5.5.w,left:0.w,top:0.h,),}, false),
                  ],),),
              ],
            )
          )
        
      ),
      
      
    );
  }
}
