import 'package:flutter/material.dart';
import 'package:flutter_ui/utils/pix_adapted_screen.dart';
import 'package:flutter_ui/components/Group.dart';
import 'package:flutter_ui/utils/pix_flutter_interface.dart';

class Filter extends StatefulWidget {

  Filter({super.key,});
  @override
  State<Filter> createState() => _FilterState();
}

class _FilterState extends State<Filter> {


  @override
  void initState() {
    super.initState();
  
  }


  @override
  Widget build(BuildContext context) {
    ScreenUtil().rootSize = Size(375, 667);
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: MediaQuery.removePadding(
        context: context,
        removeTop: true,
        removeBottom: true,
        child: SizedBox(
            width: 375.w,
            height: 667.h,
            child: ListView(
              children: [
                Container(
                width: 375.w,
                height: 667.h,
                decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                clipBehavior: Clip.hardEdge,
                child: Stack(
                  key: ValueKey("6:896"),
                  children: [
                    Positioned(
                      width: 375.w,
                      height: 64.h,
                      left: 0.w,
                      top: 0.h,
                      child: Container(
                        key: ValueKey("6:897"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, -1.w),blurRadius: 10.w,)],),),),
                    Positioned(
                      width: 42.w,
                      height: 23.h,
                      left: 167.w,
                      top: 29.h,
                      child: Text("Filter",
                        key: ValueKey("6:947"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 17.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 16.w,
                      height: 16.h,
                      left: 342.w,
                      top: 33.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("34:291"),
                          children: [
                            Positioned(
                              width: 17.41.w,
                              height: 17.41.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("34:292"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group64.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 343.w,
                      height: 44.h,
                      left: 16.w,
                      top: 110.h,
                      child: Container(
                        key: ValueKey("6:980"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),borderRadius: BorderRadius.circular(4.h),border: Border.all(width: 1.w, color: Color.fromRGBO(234, 234, 234,1), ),),),),
                    Positioned(
                      width: 44.w,
                      height: 18.h,
                      left: 16.w,
                      top: 84.h,
                      child: Text("Author",
                        key: ValueKey("6:981"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 86.w,
                      height: 18.h,
                      left: 28.w,
                      top: 123.h,
                      child: Text("Admim Smith",
                        key: ValueKey("6:982"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 10.w,
                      height: 7.5.h,
                      left: 337.w,
                      top: 128.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("34:294"),
                          children: [
                            Positioned(
                              width: 10.w,
                              height: 7.5.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("34:295"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group63.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 343.w,
                      height: 44.h,
                      left: 16.w,
                      top: 200.h,
                      child: Container(
                        key: ValueKey("6:962"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),borderRadius: BorderRadius.circular(4.h),border: Border.all(width: 1.w, color: Color.fromRGBO(234, 234, 234,1), ),),),),
                    Positioned(
                      width: 59.w,
                      height: 18.h,
                      left: 16.w,
                      top: 174.h,
                      child: Text("Category",
                        key: ValueKey("6:963"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 343.w,
                      height: 44.h,
                      left: 16.w,
                      top: 290.h,
                      child: Container(
                        key: ValueKey("6:964"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),borderRadius: BorderRadius.circular(4.h),border: Border.all(width: 1.w, color: Color.fromRGBO(234, 234, 234,1), ),),),),
                    Positioned(
                      width: 62.w,
                      height: 18.h,
                      left: 16.w,
                      top: 264.h,
                      child: Text("Language",
                        key: ValueKey("6:965"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 343.w,
                      height: 44.h,
                      left: 16.w,
                      top: 380.h,
                      child: Container(
                        key: ValueKey("6:975"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),borderRadius: BorderRadius.circular(4.h),border: Border.all(width: 1.w, color: Color.fromRGBO(234, 234, 234,1), ),),),),
                    Positioned(
                      width: 77.w,
                      height: 18.h,
                      left: 16.w,
                      top: 354.h,
                      child: Text("Publish Year",
                        key: ValueKey("6:976"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 343.w,
                      height: 46.h,
                      left: 16.w,
                      top: 605.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("95:237"),
                          children: [
                            Positioned(
                              width: 343.w,
                              height: 46.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                key: ValueKey("6:977"),
                                decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment(0,0), end: Alignment(1.0000000291545188,1.0000000217391303), colors: [Color.fromRGBO(129, 251, 184,1), Color.fromRGBO(40, 199, 111,1)], stops: [0, 1]),borderRadius: BorderRadius.circular(4.h),border: Border.all(width: 1.w, color: Colors.transparent, ),),),),
                            Positioned(
                              width: 74.w,
                              height: 19.h,
                              left: 135.w,
                              top: 14.h,
                              child: Text("Filter (120)",
                                key: ValueKey("6:978"),
                                textAlign: TextAlign.left,
                                style: TextStyle(color: Color.fromRGBO(255, 255, 255,1), fontFamily: "Circular Std", fontWeight: FontWeight.bold, fontSize: 14.6.sp, letterSpacing: 0.w),),),
                          ],),),),
                    Positioned(
                      width: 46.w,
                      height: 18.h,
                      left: 30.w,
                      top: 212.h,
                      child: Text("History",
                        key: ValueKey("6:983"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 46.w,
                      height: 18.h,
                      left: 30.w,
                      top: 301.h,
                      child: Text("English",
                        key: ValueKey("6:984"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 10.w,
                      height: 7.5.h,
                      left: 337.w,
                      top: 308.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("34:300"),
                          children: [
                            Positioned(
                              width: 10.w,
                              height: 7.5.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("34:301"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group61.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 10.w,
                      height: 7.5.h,
                      left: 337.w,
                      top: 400.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("34:303"),
                          children: [
                            Positioned(
                              width: 10.w,
                              height: 7.5.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("34:304"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group62.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 29.w,
                      height: 18.h,
                      left: 30.w,
                      top: 391.h,
                      child: Text("2018",
                        key: ValueKey("6:985"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 32.w,
                      height: 18.h,
                      left: 15.w,
                      top: 444.h,
                      child: Text("Price",
                        key: ValueKey("6:967"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 10.w,
                      height: 7.5.h,
                      left: 337.w,
                      top: 218.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("34:297"),
                          children: [
                            Positioned(
                              width: 10.w,
                              height: 7.5.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("34:298"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group60.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 343.w,
                      height: 6.h,
                      left: 16.w,
                      top: 482.h,
                      child: Container(
                        key: ValueKey("6:968"),
                        decoration: BoxDecoration(color: Color.fromRGBO(235, 235, 235,1),borderRadius: BorderRadius.circular(2.h),border: Border.all(width: 1.w, color: Colors.transparent, ),),),),
                    Positioned(
                      width: 173.w,
                      height: 6.h,
                      left: 103.w,
                      top: 482.h,
                      child: Container(
                        key: ValueKey("34:306"),
                        decoration: BoxDecoration(color: Color.fromRGBO(50, 205, 119,1),border: Border.all(width: 1.w, color: Colors.transparent, ),),),),
                    Positioned(
                      width: 22.w,
                      height: 22.h,
                      left: 82.w,
                      top: 474.h,
                      child: Image(
                        key: ValueKey("6:969"),
                        image: AssetImage("http://localhost:3667/assets/1793182110309/Ellipse5.svg.png"),),),
                    Positioned(
                      width: 10.w,
                      height: 10.h,
                      left: 88.w,
                      top: 480.h,
                      child: Image(
                        key: ValueKey("34:307"),
                        image: AssetImage("http://localhost:3667/assets/1793182110309/Ellipse4.svg.png"),),),
                    Positioned(
                      width: 22.w,
                      height: 22.h,
                      left: 273.w,
                      top: 474.h,
                      child: Image(
                        key: ValueKey("6:970"),
                        image: AssetImage("http://localhost:3667/assets/1793182110309/Ellipse7.svg.png"),),),
                    Positioned(
                      width: 16.w,
                      height: 18.h,
                      left: 85.w,
                      top: 502.h,
                      child: Text("\$3",
                        key: ValueKey("6:971"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(50, 205, 119,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 24.w,
                      height: 18.h,
                      left: 273.w,
                      top: 502.h,
                      child: Text("\$70",
                        key: ValueKey("6:972"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(50, 205, 119,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 10.w,
                      height: 10.h,
                      left: 279.w,
                      top: 480.h,
                      child: Image(
                        key: ValueKey("34:308"),
                        image: AssetImage("http://localhost:3667/assets/1793182110309/Ellipse6.svg.png"),),),
                    Group({"6:525":PixFlutterInterface(width:31.w,height:16.h,left:304.5.w,top:0.h,),"6:526":PixFlutterInterface(width:24.5.w,height:9.5.h,left:338.5.w,top:3.5.h,),"6:527":PixFlutterInterface(width:22.5.w,height:9.5.h,left:0.w,top:0.h,),"6:528":PixFlutterInterface(width:22.5.w,height:9.5.h,left:0.w,top:0.h,),"6:529":PixFlutterInterface(width:21.5.w,height:8.5.h,left:0.5.w,top:0.5.h,),"6:530":PixFlutterInterface(width:22.5.w,height:9.5.h,left:0.w,top:0.h,),"6:531":PixFlutterInterface(width:20.5.w,height:7.5.h,left:1.w,top:1.h,),"6:532":PixFlutterInterface(width:1.5.w,height:3.5.h,left:23.w,top:3.h,),"6:542":PixFlutterInterface(width:48.w,height:16.h,left:157.w,top:1.h,),"6:543":PixFlutterInterface(width:33.5.w,height:5.5.h,left:0.w,top:5.5.h,),"6:544":PixFlutterInterface(width:5.5.w,height:5.5.w,left:28.w,top:0.h,),"6:545":PixFlutterInterface(width:4.5.w,height:4.5.w,left:0.5.w,top:0.5.h,),"6:546":PixFlutterInterface(width:5.5.w,height:5.5.w,left:0.w,top:0.h,),"6:547":PixFlutterInterface(width:5.5.w,height:5.5.w,left:21.w,top:0.h,),"6:548":PixFlutterInterface(width:5.5.w,height:5.5.w,left:14.w,top:0.h,),"6:549":PixFlutterInterface(width:5.5.w,height:5.5.w,left:7.w,top:0.h,),"6:550":PixFlutterInterface(width:5.5.w,height:5.5.w,left:0.w,top:0.h,),"96:52":PixFlutterInterface(width:363.w,height:17.h,left:6.5.w,top:2.h,),}, false),
                  ],),),
              ],
            )
          )
        
      ),
      
      
    );
  }
}
