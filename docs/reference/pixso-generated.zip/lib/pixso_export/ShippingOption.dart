import 'package:flutter/material.dart';
import 'package:flutter_ui/utils/pix_adapted_screen.dart';
import 'package:flutter_ui/components/Group.dart';
import 'package:flutter_ui/utils/pix_flutter_interface.dart';

class ShippingOption extends StatefulWidget {

  ShippingOption({super.key,});
  @override
  State<ShippingOption> createState() => _ShippingOptionState();
}

class _ShippingOptionState extends State<ShippingOption> {


  @override
  void initState() {
    super.initState();
  
  }


  @override
  Widget build(BuildContext context) {
    ScreenUtil().rootSize = Size(375, 667);
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: MediaQuery.removePadding(
        context: context,
        removeTop: true,
        removeBottom: true,
        child: SizedBox(
            width: 375.w,
            height: 667.h,
            child: ListView(
              children: [
                Container(
                width: 375.w,
                height: 667.h,
                decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                clipBehavior: Clip.hardEdge,
                child: Stack(
                  key: ValueKey("6:348"),
                  children: [
                    Positioned(
                      width: 375.w,
                      height: 59.h,
                      left: 0.w,
                      top: 123.h,
                      child: Container(
                        key: ValueKey("95:234"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, 0.w),blurRadius: 5.w,)],),),),
                    Positioned(
                      width: 375.w,
                      height: 59.h,
                      left: 0.w,
                      top: 240.h,
                      child: Container(
                        key: ValueKey("95:235"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, 0.w),blurRadius: 5.w,)],),),),
                    Positioned(
                      width: 375.w,
                      height: 59.h,
                      left: 0.w,
                      top: 64.h,
                      child: Container(
                        key: ValueKey("95:233"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, 0.w),blurRadius: 5.w,)],),),),
                    Positioned(
                      width: 375.w,
                      height: 58.h,
                      left: 0.w,
                      top: 182.h,
                      child: Container(
                        key: ValueKey("33:169"),
                        decoration: BoxDecoration(color: Color.fromRGBO(248, 248, 248,1),border: Border.all(width: 1.w, color: Colors.transparent, ),),),),
                    Positioned(
                      width: 375.w,
                      height: 64.h,
                      left: 0.w,
                      top: 0.h,
                      child: Container(
                        key: ValueKey("6:349"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, -1.w),blurRadius: 10.w,)],),),),
                    Positioned(
                      width: 141.w,
                      height: 23.h,
                      left: 117.w,
                      top: 29.h,
                      child: Text("Shipping Options",
                        key: ValueKey("6:350"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 17.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 182.w,
                      height: 18.h,
                      left: 48.w,
                      top: 84.h,
                      child: Text("Standard (5-9 Business Days)",
                        key: ValueKey("6:378"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 33.w,
                      height: 18.h,
                      left: 327.w,
                      top: 84.h,
                      child: Text("FREE",
                        key: ValueKey("6:397"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(238, 39, 39,1), fontFamily: "Circular Std", fontWeight: FontWeight.w500, fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 340.w,
                      height: 46.h,
                      left: 18.w,
                      top: 605.h,
                      child: Container(
                        key: ValueKey("6:394"),
                        decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment(0,0), end: Alignment(1.0000000294117646,1.0000000217391303), colors: [Color.fromRGBO(129, 251, 184,1), Color.fromRGBO(40, 199, 111,1)], stops: [0, 1]),borderRadius: BorderRadius.circular(4.h),border: Border.all(width: 1.w, color: Colors.transparent, ),),),),
                    Positioned(
                      width: 74.w,
                      height: 20.h,
                      left: 151.w,
                      top: 618.h,
                      child: Text("Countinue",
                        key: ValueKey("6:395"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(255, 255, 255,1), fontFamily: "Circular Std", fontWeight: FontWeight.bold, fontSize: 14.6.sp, height: 1.3333333333333333, letterSpacing: 0.w),),),
                    Positioned(
                      width: 20.w,
                      height: 20.h,
                      left: 16.w,
                      top: 83.h,
                      child: Image(
                        key: ValueKey("6:396"),
                        image: AssetImage("http://localhost:3667/assets/1793182110309/Ellipse0.svg.png"),),),
                    Positioned(
                      width: 188.w,
                      height: 18.h,
                      left: 48.w,
                      top: 143.h,
                      child: Text("Expedited (2-6 Business Days)",
                        key: ValueKey("6:398"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 34.w,
                      height: 18.h,
                      left: 325.w,
                      top: 143.h,
                      child: Text("\$1.99",
                        key: ValueKey("6:399"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(50, 205, 119,1), fontFamily: "Circular Std", fontWeight: FontWeight.w500, fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 20.w,
                      height: 20.h,
                      left: 16.w,
                      top: 142.h,
                      child: Image(
                        key: ValueKey("6:400"),
                        image: AssetImage("http://localhost:3667/assets/1793182110309/Ellipse.svg.png"),),),
                    Positioned(
                      width: 149.w,
                      height: 18.h,
                      left: 48.w,
                      top: 202.h,
                      child: Text("2-Day (3 Business Days)",
                        key: ValueKey("6:401"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 37.w,
                      height: 18.h,
                      left: 323.w,
                      top: 202.h,
                      child: Text("\$3.99",
                        key: ValueKey("6:402"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(50, 205, 119,1), fontFamily: "Circular Std", fontWeight: FontWeight.w500, fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 20.w,
                      height: 20.h,
                      left: 16.w,
                      top: 201.h,
                      child: Image(
                        key: ValueKey("6:403"),
                        image: AssetImage("http://localhost:3667/assets/1793182110309/Ellipse2.svg.png"),),),
                    Positioned(
                      width: 10.w,
                      height: 10.h,
                      left: 21.w,
                      top: 206.h,
                      child: Image(
                        key: ValueKey("33:170"),
                        image: AssetImage("http://localhost:3667/assets/1793182110309/Ellipse1.svg.png"),),),
                    Positioned(
                      width: 150.w,
                      height: 18.h,
                      left: 45.w,
                      top: 261.h,
                      child: Text(" 1-Day (2 Business Days)",
                        key: ValueKey("6:404"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 37.w,
                      height: 18.h,
                      left: 323.w,
                      top: 261.h,
                      child: Text("\$5.99",
                        key: ValueKey("6:405"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(50, 205, 119,1), fontFamily: "Circular Std", fontWeight: FontWeight.w500, fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 20.w,
                      height: 20.h,
                      left: 16.w,
                      top: 260.h,
                      child: Image(
                        key: ValueKey("6:406"),
                        image: AssetImage("http://localhost:3667/assets/1793182110309/Ellipse3.svg.png"),),),
                    Positioned(
                      width: 12.01.w,
                      height: 20.h,
                      left: 15.38.w,
                      top: 30.h,
                      child: Image(
                        key: ValueKey("38:50"),
                        image: AssetImage("http://localhost:3667/assets/1793182110309/BackArrowStroke.svg.png"),),),
                    Group({"6:525":PixFlutterInterface(textColor:Color.fromRGBO(34, 34, 59,1),width:31.w,height:16.h,left:304.5.w,top:0.h,),"6:526":PixFlutterInterface(backgroundColor:Color.fromRGBO(34, 34, 59,1),width:24.5.w,height:9.5.h,left:338.5.w,top:3.5.h,),"6:542":PixFlutterInterface(textColor:Color.fromRGBO(34, 34, 59,1),width:48.w,height:16.h,left:157.w,top:1.h,),"6:543":PixFlutterInterface(backgroundColor:Color.fromRGBO(34, 34, 59,1),width:33.5.w,height:5.5.h,left:0.w,top:5.5.h,),"96:52":PixFlutterInterface(width:363.w,height:17.h,left:6.5.w,top:2.h,),"6:527":PixFlutterInterface(width:22.5.w,height:9.5.h,left:0.w,top:0.h,),"6:528":PixFlutterInterface(width:22.5.w,height:9.5.h,left:0.w,top:0.h,),"6:529":PixFlutterInterface(width:21.5.w,height:8.5.h,left:0.5.w,top:0.5.h,),"6:530":PixFlutterInterface(width:22.5.w,height:9.5.h,left:0.w,top:0.h,),"6:531":PixFlutterInterface(width:20.5.w,height:7.5.h,left:1.w,top:1.h,),"6:532":PixFlutterInterface(width:1.5.w,height:3.5.h,left:23.w,top:3.h,),"6:544":PixFlutterInterface(width:5.5.w,height:5.5.w,left:28.w,top:0.h,),"6:545":PixFlutterInterface(width:4.5.w,height:4.5.w,left:0.5.w,top:0.5.h,),"6:546":PixFlutterInterface(width:5.5.w,height:5.5.w,left:0.w,top:0.h,),"6:547":PixFlutterInterface(width:5.5.w,height:5.5.w,left:21.w,top:0.h,),"6:548":PixFlutterInterface(width:5.5.w,height:5.5.w,left:14.w,top:0.h,),"6:549":PixFlutterInterface(width:5.5.w,height:5.5.w,left:7.w,top:0.h,),"6:550":PixFlutterInterface(width:5.5.w,height:5.5.w,left:0.w,top:0.h,),}, false),
                  ],),),
              ],
            )
          )
        
      ),
      
      
    );
  }
}
