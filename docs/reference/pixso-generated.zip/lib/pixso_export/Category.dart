import 'package:flutter/material.dart';
import 'package:flutter_ui/utils/pix_adapted_screen.dart';
import 'package:flutter_ui/components/Group.dart';
import 'package:flutter_ui/utils/pix_flutter_interface.dart';

class Category extends StatefulWidget {

  Category({super.key,});
  @override
  State<Category> createState() => _CategoryState();
}

class _CategoryState extends State<Category> {


  @override
  void initState() {
    super.initState();
  
  }


  @override
  Widget build(BuildContext context) {
    ScreenUtil().rootSize = Size(375, 703);
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: MediaQuery.removePadding(
        context: context,
        removeTop: true,
        removeBottom: true,
        child: SizedBox(
            width: 375.w,
            height: 703.h,
            child: ListView(
              children: [
                Container(
                width: 375.w,
                height: 703.h,
                decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                clipBehavior: Clip.hardEdge,
                child: Stack(
                  key: ValueKey("4:123"),
                  children: [
                    Positioned(
                      width: 375.w,
                      height: 58.h,
                      left: 0.w,
                      top: 123.h,
                      child: Container(
                        key: ValueKey("14:54"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, 0.w),blurRadius: 5.w,)],),),),
                    Positioned(
                      width: 375.w,
                      height: 58.h,
                      left: 0.w,
                      top: 239.h,
                      child: Container(
                        key: ValueKey("14:56"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, 0.w),blurRadius: 5.w,)],),),),
                    Positioned(
                      width: 375.w,
                      height: 58.h,
                      left: 0.w,
                      top: 181.h,
                      child: Container(
                        key: ValueKey("14:55"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, 0.w),blurRadius: 5.w,)],),),),
                    Positioned(
                      width: 375.w,
                      height: 58.h,
                      left: 0.w,
                      top: 297.h,
                      child: Container(
                        key: ValueKey("14:57"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, 0.w),blurRadius: 5.w,)],),),),
                    Positioned(
                      width: 375.w,
                      height: 58.h,
                      left: 0.w,
                      top: 413.h,
                      child: Container(
                        key: ValueKey("14:58"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, 0.w),blurRadius: 5.w,)],),),),
                    Positioned(
                      width: 375.w,
                      height: 58.h,
                      left: 0.w,
                      top: 355.h,
                      child: Container(
                        key: ValueKey("14:59"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, 0.w),blurRadius: 5.w,)],),),),
                    Positioned(
                      width: 375.w,
                      height: 58.h,
                      left: 0.w,
                      top: 471.h,
                      child: Container(
                        key: ValueKey("14:60"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, 0.w),blurRadius: 5.w,)],),),),
                    Positioned(
                      width: 375.w,
                      height: 58.h,
                      left: 0.w,
                      top: 529.h,
                      child: Container(
                        key: ValueKey("14:61"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, 0.w),blurRadius: 5.w,)],),),),
                    Positioned(
                      width: 375.w,
                      height: 58.h,
                      left: 0.w,
                      top: 645.h,
                      child: Container(
                        key: ValueKey("14:62"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, 0.w),blurRadius: 5.w,)],),),),
                    Positioned(
                      width: 375.w,
                      height: 58.h,
                      left: 0.w,
                      top: 587.h,
                      child: Container(
                        key: ValueKey("14:63"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, 0.w),blurRadius: 5.w,)],),),),
                    Positioned(
                      width: 117.w,
                      height: 18.h,
                      left: 16.w,
                      top: 84.h,
                      child: Text("Art & Photography",
                        key: ValueKey("5:84"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 10.73.w,
                      height: 18.h,
                      left: 349.w,
                      top: 84.h,
                      child: Image(
                        key: ValueKey("14:37"),
                        image: AssetImage("http://localhost:3667/assets/1793182110309/Vector7.svg.png"),),),
                    Positioned(
                      width: 10.73.w,
                      height: 18.h,
                      left: 349.w,
                      top: 143.h,
                      child: Image(
                        key: ValueKey("14:38"),
                        image: AssetImage("http://localhost:3667/assets/1793182110309/Vector6.svg.png"),),),
                    Positioned(
                      width: 10.73.w,
                      height: 18.h,
                      left: 349.w,
                      top: 201.h,
                      child: Image(
                        key: ValueKey("14:39"),
                        image: AssetImage("http://localhost:3667/assets/1793182110309/Vector5.svg.png"),),),
                    Positioned(
                      width: 10.73.w,
                      height: 18.h,
                      left: 349.w,
                      top: 259.h,
                      child: Image(
                        key: ValueKey("14:40"),
                        image: AssetImage("http://localhost:3667/assets/1793182110309/Vector15.svg.png"),),),
                    Positioned(
                      width: 10.73.w,
                      height: 18.h,
                      left: 349.w,
                      top: 317.h,
                      child: Image(
                        key: ValueKey("14:41"),
                        image: AssetImage("http://localhost:3667/assets/1793182110309/Vector11.svg.png"),),),
                    Positioned(
                      width: 10.73.w,
                      height: 18.h,
                      left: 349.w,
                      top: 375.h,
                      child: Image(
                        key: ValueKey("14:42"),
                        image: AssetImage("http://localhost:3667/assets/1793182110309/Vector12.svg.png"),),),
                    Positioned(
                      width: 10.73.w,
                      height: 18.h,
                      left: 349.w,
                      top: 433.h,
                      child: Image(
                        key: ValueKey("14:43"),
                        image: AssetImage("http://localhost:3667/assets/1793182110309/Vector10.svg.png"),),),
                    Positioned(
                      width: 10.73.w,
                      height: 18.h,
                      left: 349.w,
                      top: 491.h,
                      child: Image(
                        key: ValueKey("14:44"),
                        image: AssetImage("http://localhost:3667/assets/1793182110309/Vector9.svg.png"),),),
                    Positioned(
                      width: 10.73.w,
                      height: 18.h,
                      left: 349.w,
                      top: 549.h,
                      child: Image(
                        key: ValueKey("14:45"),
                        image: AssetImage("http://localhost:3667/assets/1793182110309/Vector14.svg.png"),),),
                    Positioned(
                      width: 10.73.w,
                      height: 18.h,
                      left: 349.w,
                      top: 607.h,
                      child: Image(
                        key: ValueKey("14:46"),
                        image: AssetImage("http://localhost:3667/assets/1793182110309/Vector13.svg.png"),),),
                    Positioned(
                      width: 375.w,
                      height: 64.h,
                      left: 0.w,
                      top: 0.h,
                      child: Container(
                        key: ValueKey("5:54"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, -1.w),blurRadius: 10.w,)],),),),
                    Positioned(
                      width: 89.w,
                      height: 23.h,
                      left: 143.w,
                      top: 29.h,
                      child: Text("Categories",
                        key: ValueKey("5:55"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 17.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 65.w,
                      height: 18.h,
                      left: 15.w,
                      top: 143.h,
                      child: Text("Biography",
                        key: ValueKey("6:472"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 105.w,
                      height: 18.h,
                      left: 16.w,
                      top: 201.h,
                      child: Text("Children's Books",
                        key: ValueKey("6:477"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 107.w,
                      height: 18.h,
                      left: 16.w,
                      top: 259.h,
                      child: Text("Crafts & Hobbies",
                        key: ValueKey("6:482"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 99.w,
                      height: 18.h,
                      left: 16.w,
                      top: 317.h,
                      child: Text("Crime & Thriller",
                        key: ValueKey("6:487"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 43.w,
                      height: 18.h,
                      left: 16.w,
                      top: 375.h,
                      child: Text("Fiction",
                        key: ValueKey("6:492"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 82.w,
                      height: 18.h,
                      left: 16.w,
                      top: 433.h,
                      child: Text("Food & Drink",
                        key: ValueKey("6:497"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 205.w,
                      height: 18.h,
                      left: 16.w,
                      top: 491.h,
                      child: Text("Graphic Novels, Anime & Manga",
                        key: ValueKey("6:502"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 142.w,
                      height: 18.h,
                      left: 16.w,
                      top: 549.h,
                      child: Text("History & Archaeology",
                        key: ValueKey("6:507"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 122.w,
                      height: 18.h,
                      left: 16.w,
                      top: 607.h,
                      child: Text("Mind, Body & Spirit",
                        key: ValueKey("6:512"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 10.73.w,
                      height: 18.h,
                      left: 349.w,
                      top: 665.h,
                      child: Image(
                        key: ValueKey("14:48"),
                        image: AssetImage("http://localhost:3667/assets/1793182110309/Vector8.svg.png"),),),
                    Positioned(
                      width: 98.w,
                      height: 18.h,
                      left: 16.w,
                      top: 665.h,
                      child: Text("Social Sciences",
                        key: ValueKey("14:50"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 12.01.w,
                      height: 20.h,
                      left: 15.38.w,
                      top: 30.h,
                      child: Image(
                        key: ValueKey("38:45"),
                        image: AssetImage("http://localhost:3667/assets/1793182110309/BackArrowStroke6.svg.png"),),),
                    Group({"6:525":PixFlutterInterface(textColor:Color.fromRGBO(34, 34, 59,1),width:31.w,height:16.h,left:304.5.w,top:0.h,),"6:526":PixFlutterInterface(backgroundColor:Color.fromRGBO(34, 34, 59,1),width:24.5.w,height:9.5.h,left:338.5.w,top:3.5.h,),"6:542":PixFlutterInterface(textColor:Color.fromRGBO(34, 34, 59,1),width:48.w,height:16.h,left:157.w,top:1.h,),"6:543":PixFlutterInterface(backgroundColor:Color.fromRGBO(34, 34, 59,1),width:33.5.w,height:5.5.h,left:0.w,top:5.5.h,),"96:52":PixFlutterInterface(width:363.w,height:17.h,left:6.5.w,top:2.h,),"6:527":PixFlutterInterface(width:22.5.w,height:9.5.h,left:0.w,top:0.h,),"6:528":PixFlutterInterface(width:22.5.w,height:9.5.h,left:0.w,top:0.h,),"6:529":PixFlutterInterface(width:21.5.w,height:8.5.h,left:0.5.w,top:0.5.h,),"6:530":PixFlutterInterface(width:22.5.w,height:9.5.h,left:0.w,top:0.h,),"6:531":PixFlutterInterface(width:20.5.w,height:7.5.h,left:1.w,top:1.h,),"6:532":PixFlutterInterface(width:1.5.w,height:3.5.h,left:23.w,top:3.h,),"6:544":PixFlutterInterface(width:5.5.w,height:5.5.w,left:28.w,top:0.h,),"6:545":PixFlutterInterface(width:4.5.w,height:4.5.w,left:0.5.w,top:0.5.h,),"6:546":PixFlutterInterface(width:5.5.w,height:5.5.w,left:0.w,top:0.h,),"6:547":PixFlutterInterface(width:5.5.w,height:5.5.w,left:21.w,top:0.h,),"6:548":PixFlutterInterface(width:5.5.w,height:5.5.w,left:14.w,top:0.h,),"6:549":PixFlutterInterface(width:5.5.w,height:5.5.w,left:7.w,top:0.h,),"6:550":PixFlutterInterface(width:5.5.w,height:5.5.w,left:0.w,top:0.h,),}, false),
                  ],),),
              ],
            )
          )
        
      ),
      
      
    );
  }
}
