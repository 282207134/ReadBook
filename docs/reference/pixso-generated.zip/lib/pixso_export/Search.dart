import 'package:flutter/material.dart';
import 'package:flutter_ui/utils/pix_adapted_screen.dart';
import 'package:flutter_ui/utils/pix_text_rich.dart';
import 'package:flutter_ui/custom_widget/CustomWidget_34_205.dart';
import 'package:flutter_ui/components/Group.dart';
import 'package:flutter_ui/utils/pix_flutter_interface.dart';

class Search extends StatefulWidget {

  Search({super.key,});
  @override
  State<Search> createState() => _SearchState();
}

class _SearchState extends State<Search> {


  @override
  void initState() {
    super.initState();
  
  }


  @override
  Widget build(BuildContext context) {
    ScreenUtil().rootSize = Size(375, 667);
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: MediaQuery.removePadding(
        context: context,
        removeTop: true,
        removeBottom: true,
        child: SizedBox(
            width: 375.w,
            height: 667.h,
            child: ListView(
              children: [
                Container(
                width: 375.w,
                height: 667.h,
                decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                clipBehavior: Clip.hardEdge,
                child: Stack(
                  key: ValueKey("6:788"),
                  children: [
                    Positioned(
                      width: 375.w,
                      height: 42.h,
                      left: 0.w,
                      top: 64.h,
                      child: Container(
                        key: ValueKey("95:241"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, 0.w),blurRadius: 5.w,)],),),),
                    Positioned(
                      width: 375.w,
                      height: 64.h,
                      left: 0.w,
                      top: 0.h,
                      child: Container(
                        key: ValueKey("6:789"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, -1.w),blurRadius: 10.w,)],),),),
                    Positioned(
                      width: 343.w,
                      height: 30.h,
                      left: 16.w,
                      top: 24.h,
                      child: Container(
                        key: ValueKey("6:876"),
                        decoration: BoxDecoration(borderRadius: BorderRadius.circular(4.h),border: Border.all(width: 1.w, color: Color.fromRGBO(234, 234, 234,1), ),),),),
                    Positioned(
                      width: 110.w,
                      height: 18.h,
                      left: 16.w,
                      top: 76.h,
                      child: Text("Top Hot Keyword",
                        key: ValueKey("6:878"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 112.w,
                      height: 18.h,
                      left: 16.w,
                      top: 126.h,
                      child: Text("A Wrinkle in Time",
                        key: ValueKey("6:879"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(167, 167, 177,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 153.w,
                      height: 18.h,
                      left: 16.w,
                      top: 160.h,
                      child: Text("The President Is Missing",
                        key: ValueKey("6:882"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(167, 167, 177,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 112.w,
                      height: 18.h,
                      left: 16.w,
                      top: 194.h,
                      child: Text("James W Loewen",
                        key: ValueKey("6:883"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(167, 167, 177,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 140.w,
                      height: 18.h,
                      left: 16.w,
                      top: 228.h,
                      child: Text("The Guernsey Literary",
                        key: ValueKey("34:289"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(167, 167, 177,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 98.w,
                      height: 18.h,
                      left: 16.w,
                      top: 262.h,
                      child: Text("Bob Woodward",
                        key: ValueKey("34:290"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(167, 167, 177,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 60.w,
                      height: 16.h,
                      left: 158.w,
                      top: 31.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Opacity(
                          opacity: 0.5,
                          child: Stack(
                            key: ValueKey("34:204"),
                            children: [
                              Positioned(
                                width: 38.w,
                                height: 16.h,
                                left: 22.w,
                                top: 0.h,
                                child: Text("Search",
                                  key: ValueKey("6:875"),
                                  textAlign: TextAlign.left,
                                  style: TextStyle(color: Color.fromRGBO(34, 34, 59,1), fontFamily: "Circular Std", fontSize: 11.6.sp, letterSpacing: 0.w),),),
                              Positioned(
                                width: 14.w,
                                height: 14.h,
                                left: 0.w,
                                top: 1.h,
                                child: Container(
                                  decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                                  clipBehavior: Clip.hardEdge,
                                  child: Stack(
                                    key: ValueKey("34:200"),
                                    children: [
                                      Positioned(
                                        width: 14.85.w,
                                        height: 14.85.h,
                                        left: 0.w,
                                        top: 0.h,
                                        child: Container(
                                          clipBehavior: Clip.hardEdge,
                                          decoration: BoxDecoration(),
                                          child: Image(
                                            key: ValueKey("34:201"),
                                            image: AssetImage("http://localhost:3667/assets/1793182110309/Group65.svg.png"),),),),
                                    ],),),),
                            ],),),),),
                    CustomWidget_34_205(),
                    Group({"96:52":PixFlutterInterface(width:363.w,height:17.h,left:6.5.w,top:2.h,),"6:525":PixFlutterInterface(width:31.w,height:16.h,left:304.5.w,top:0.h,),"6:526":PixFlutterInterface(width:24.5.w,height:9.5.h,left:338.5.w,top:3.5.h,),"6:527":PixFlutterInterface(width:22.5.w,height:9.5.h,left:0.w,top:0.h,),"6:528":PixFlutterInterface(width:22.5.w,height:9.5.h,left:0.w,top:0.h,),"6:529":PixFlutterInterface(width:21.5.w,height:8.5.h,left:0.5.w,top:0.5.h,),"6:530":PixFlutterInterface(width:22.5.w,height:9.5.h,left:0.w,top:0.h,),"6:531":PixFlutterInterface(width:20.5.w,height:7.5.h,left:1.w,top:1.h,),"6:532":PixFlutterInterface(width:1.5.w,height:3.5.h,left:23.w,top:3.h,),"6:542":PixFlutterInterface(width:48.w,height:16.h,left:157.w,top:1.h,),"6:543":PixFlutterInterface(width:33.5.w,height:5.5.h,left:0.w,top:5.5.h,),"6:544":PixFlutterInterface(width:5.5.w,height:5.5.w,left:28.w,top:0.h,),"6:545":PixFlutterInterface(width:4.5.w,height:4.5.w,left:0.5.w,top:0.5.h,),"6:546":PixFlutterInterface(width:5.5.w,height:5.5.w,left:0.w,top:0.h,),"6:547":PixFlutterInterface(width:5.5.w,height:5.5.w,left:21.w,top:0.h,),"6:548":PixFlutterInterface(width:5.5.w,height:5.5.w,left:14.w,top:0.h,),"6:549":PixFlutterInterface(width:5.5.w,height:5.5.w,left:7.w,top:0.h,),"6:550":PixFlutterInterface(width:5.5.w,height:5.5.w,left:0.w,top:0.h,),}, false),
                  ],),),
              ],
            )
          )
        
      ),
      
      
    );
  }
}
