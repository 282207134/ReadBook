import 'package:flutter/material.dart';
import 'package:flutter_ui/utils/pix_adapted_screen.dart';
import 'package:flutter_ui/custom_widget/CustomWidget_14_107.dart';
import 'package:flutter_ui/utils/pix_text_rich.dart';
import 'package:flutter_ui/custom_widget/CustomWidget_5_94.dart';
import 'package:flutter_ui/custom_widget/CustomWidget_14_116.dart';
import 'package:flutter_ui/custom_widget/CustomWidget_14_90.dart';
import 'package:flutter_ui/components/Group.dart';
import 'package:flutter_ui/utils/pix_flutter_interface.dart';

class BookDetail extends StatefulWidget {

  BookDetail({super.key,});
  @override
  State<BookDetail> createState() => _BookDetailState();
}

class _BookDetailState extends State<BookDetail> {


  @override
  void initState() {
    super.initState();
  
  }


  @override
  Widget build(BuildContext context) {
    ScreenUtil().rootSize = Size(375, 812);
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: MediaQuery.removePadding(
        context: context,
        removeTop: true,
        removeBottom: true,
        child: SizedBox(
            width: 375.w,
            height: 812.h,
            child: ListView(
              children: [
                Container(
                width: 375.w,
                height: 1436.h,
                decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                clipBehavior: Clip.hardEdge,
                child: Stack(
                  key: ValueKey("4:206"),
                  children: [
                    Positioned(
                      width: 375.w,
                      height: 388.h,
                      left: 0.w,
                      top: 970.h,
                      child: Container(
                        key: ValueKey("94:74"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, 0.w),blurRadius: 5.w,)],),),),
                    Positioned(
                      width: 375.w,
                      height: 250.h,
                      left: 0.w,
                      top: 720.h,
                      child: Container(
                        key: ValueKey("94:73"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, 0.w),blurRadius: 5.w,)],),),),
                    Positioned(
                      width: 375.w,
                      height: 215.h,
                      left: 0.w,
                      top: 505.h,
                      child: Container(
                        key: ValueKey("94:16"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, 0.w),blurRadius: 5.w,)],),),),
                    Positioned(
                      width: 177.w,
                      height: 269.h,
                      left: 103.w,
                      top: 98.h,
                      child: Container(
                        key: ValueKey("14:69"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),borderRadius: BorderRadius.circular(8.h),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.2),offset: Offset(0.w, 20.w),blurRadius: 20.w,)],),),),
                    Positioned(
                      width: 177.w,
                      height: 271.h,
                      left: 103.w,
                      top: 96.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("94:10"),
                          children: [
                            Positioned(
                              width: 177.w,
                              height: 271.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                key: ValueKey("94:8"),
                                decoration: BoxDecoration(image: DecorationImage(image: AssetImage("assets/images/2f59304b2e626413eb3be25dcaf9bab3fdf89f2e.png"), fit: BoxFit.cover),borderRadius: BorderRadius.circular(8.h),border: Border.all(width: 1.w, color: Colors.transparent, ),),),),
                          ],),),),
                    Positioned(
                      width: 375.w,
                      height: 64.h,
                      left: 0.w,
                      top: 0.h,
                      child: Container(
                        key: ValueKey("4:207"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, -1.w),blurRadius: 10.w,)],),),),
                    Positioned(
                      width: 159.w,
                      height: 31.h,
                      left: 108.w,
                      top: 392.h,
                      child: Text("Blue Highways",
                        key: ValueKey("4:217"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 23.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 109.w,
                      height: 21.h,
                      left: 133.w,
                      top: 427.h,
                      child: Text("Steven Holzner",
                        key: ValueKey("4:218"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(167, 167, 177,1), fontFamily: "Circular Std", fontSize: 15.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 343.w,
                      height: 113.h,
                      left: 15.w,
                      top: 533.h,
                      child: Text("For an introductory-level course in natural hazards  \"Natural Hazards\" \"uses real-life examples of hazards and disasters to explore how and why they happen and what we can do to limit their effects. The text is up-to-date coverage of recent disasters brings a fresh perspective to the material.",
                        key: ValueKey("4:220"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.5714285714285714, letterSpacing: 0.w),),),
                    Positioned(
                      width: 343.w,
                      height: 62.h,
                      left: 16.w,
                      top: 1090.h,
                      child: Text("This is one of the most interesting textbooks I have ever read. I actually read everything in this book and retained more than needed information.",
                        key: ValueKey("4:238"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.4285714285714286, letterSpacing: 0.w),),),
                    Positioned(
                      width: 91.w,
                      height: 20.h,
                      left: 15.w,
                      top: 748.h,
                      child: Text("Book Details",
                        key: ValueKey("5:92"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 15.6.sp, height: 1.25, letterSpacing: 0.w),),),
                    Positioned(
                      width: 133.w,
                      height: 20.h,
                      left: 15.w,
                      top: 998.h,
                      child: Text("Reviews This Book",
                        key: ValueKey("4:231"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 15.6.sp, height: 1.25, letterSpacing: 0.w),),),
                    Positioned(
                      width: 91.w,
                      height: 20.h,
                      left: 68.w,
                      top: 1042.h,
                      child: Text("Nicholas\tKlein",
                        key: ValueKey("4:235"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.4285714285714286, letterSpacing: 0.w),),),
                    CustomWidget_14_107(),
                    Positioned(
                      width: 68.w,
                      height: 20.h,
                      left: 292.w,
                      top: 1044.h,
                      child: Text("July 15, 2018",
                        key: ValueKey("4:236"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(167, 167, 177,1), fontFamily: "Circular Std", fontSize: 11.6.sp, height: 1.6666666666666667, letterSpacing: 0.w),),),
                    Positioned(
                      width: 71.w,
                      height: 20.h,
                      left: 15.w,
                      top: 676.h,
                      child: Text("Read more".toUpperCase(),
                        key: ValueKey("4:223"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(3, 150, 255,1), fontFamily: "Circular Std", fontWeight: FontWeight.w500, fontSize: 11.6.sp, height: 1.6666666666666667, letterSpacing: 0.w),),),
                    Positioned(
                      width: 343.w,
                      height: 46.h,
                      left: 16.w,
                      top: 1374.h,
                      child: Container(
                        key: ValueKey("4:225"),
                        decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment(0,0), end: Alignment(1.0000000291545188,1.0000000217391303), colors: [Color.fromRGBO(129, 251, 184,1), Color.fromRGBO(40, 199, 111,1)], stops: [0, 1]),borderRadius: BorderRadius.circular(4.h),border: Border.all(width: 1.w, color: Colors.transparent, ),),),),
                    Positioned(
                      width: 154.w,
                      height: 20.h,
                      left: 111.w,
                      top: 1387.h,
                      child: Text("Add to Basket - \$18.99",
                        key: ValueKey("4:228"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(255, 255, 255,1), fontFamily: "Circular Std", fontWeight: FontWeight.bold, fontSize: 14.6.sp, height: 1.3333333333333333, letterSpacing: 0.w),),),
                    Positioned(
                      width: 40.w,
                      height: 40.h,
                      left: 16.w,
                      top: 1038.h,
                      child: Container(
                        clipBehavior: Clip.hardEdge,
                        decoration: BoxDecoration(),
                        child: Image(
                          key: ValueKey("36:278"),
                          image: AssetImage("http://localhost:3667/assets/1793182110309/MaskGroup.png.png"),),),),
                    CustomWidget_5_94(),
                    Positioned(
                      width: 41.w,
                      height: 20.h,
                      left: 39.w,
                      top: 1156.h,
                      child: Text("12 Like".toUpperCase(),
                        key: ValueKey("6:36"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(50, 205, 119,1), fontFamily: "Circular Std", fontWeight: FontWeight.bold, fontSize: 11.6.sp, height: 1.6666666666666667, letterSpacing: 0.w),),),
                    Positioned(
                      width: 14.w,
                      height: 14.h,
                      left: 17.w,
                      top: 1154.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("14:109"),
                          children: [
                            Positioned(
                              width: 15.01.w,
                              height: 15.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("14:110"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group95.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 343.w,
                      height: 62.h,
                      left: 16.w,
                      top: 1248.h,
                      child: Text("As a scientist, the claims presented in this book struck me as over confident. Science almost never gives clear cut, black and white answers.",
                        key: ValueKey("14:114"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.4285714285714286, letterSpacing: 0.w),),),
                    Positioned(
                      width: 78.w,
                      height: 20.h,
                      left: 68.w,
                      top: 1200.h,
                      child: Text("Allen\tGarcia",
                        key: ValueKey("14:115"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.4285714285714286, letterSpacing: 0.w),),),
                    CustomWidget_14_116(),
                    Positioned(
                      width: 68.w,
                      height: 20.h,
                      left: 292.w,
                      top: 1202.h,
                      child: Text("July 12, 2018",
                        key: ValueKey("14:132"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(167, 167, 177,1), fontFamily: "Circular Std", fontSize: 11.6.sp, height: 1.6666666666666667, letterSpacing: 0.w),),),
                    Positioned(
                      width: 40.w,
                      height: 40.h,
                      left: 16.w,
                      top: 1196.h,
                      child: Container(
                        clipBehavior: Clip.hardEdge,
                        decoration: BoxDecoration(),
                        child: Image(
                          key: ValueKey("36:281"),
                          image: AssetImage("http://localhost:3667/assets/1793182110309/MaskGroup.png.png"),),),),
                    Positioned(
                      width: 35.w,
                      height: 20.h,
                      left: 39.w,
                      top: 1314.h,
                      child: Text("7 Like".toUpperCase(),
                        key: ValueKey("14:134"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(50, 205, 119,1), fontFamily: "Circular Std", fontWeight: FontWeight.bold, fontSize: 11.6.sp, height: 1.6666666666666667, letterSpacing: 0.w),),),
                    Positioned(
                      width: 14.w,
                      height: 14.h,
                      left: 17.w,
                      top: 1312.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("14:135"),
                          children: [
                            Positioned(
                              width: 15.01.w,
                              height: 15.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("14:136"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group96.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 94.w,
                      height: 23.h,
                      left: 141.w,
                      top: 29.h,
                      child: Text("Book Detail",
                        key: ValueKey("14:64"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 17.6.sp, letterSpacing: 0.w),),),
                    CustomWidget_14_90(),
                    Positioned(
                      width: 12.01.w,
                      height: 20.h,
                      left: 15.38.w,
                      top: 30.h,
                      child: Image(
                        key: ValueKey("38:46"),
                        image: AssetImage("http://localhost:3667/assets/1793182110309/BackArrowStroke7.svg.png"),),),
                    Positioned(
                      width: 56.w,
                      height: 16.h,
                      left: 303.w,
                      top: 1000.h,
                      child: Text("View all".toUpperCase(),
                        key: ValueKey("94:6"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(3, 150, 255,1), fontFamily: "Circular Std", fontWeight: FontWeight.w500, fontSize: 11.6.sp, letterSpacing: 0.w),),),
                    Group({"6:525":PixFlutterInterface(textColor:Color.fromRGBO(34, 34, 59,1),width:31.w,height:16.h,left:304.5.w,top:0.h,),"6:526":PixFlutterInterface(backgroundColor:Color.fromRGBO(34, 34, 59,1),width:24.5.w,height:9.5.h,left:338.5.w,top:3.5.h,),"6:542":PixFlutterInterface(textColor:Color.fromRGBO(34, 34, 59,1),width:48.w,height:16.h,left:157.w,top:1.h,),"6:543":PixFlutterInterface(backgroundColor:Color.fromRGBO(34, 34, 59,1),width:33.5.w,height:5.5.h,left:0.w,top:5.5.h,),"96:52":PixFlutterInterface(width:363.w,height:17.h,left:6.5.w,top:2.h,),"6:527":PixFlutterInterface(width:22.5.w,height:9.5.h,left:0.w,top:0.h,),"6:528":PixFlutterInterface(width:22.5.w,height:9.5.h,left:0.w,top:0.h,),"6:529":PixFlutterInterface(width:21.5.w,height:8.5.h,left:0.5.w,top:0.5.h,),"6:530":PixFlutterInterface(width:22.5.w,height:9.5.h,left:0.w,top:0.h,),"6:531":PixFlutterInterface(width:20.5.w,height:7.5.h,left:1.w,top:1.h,),"6:532":PixFlutterInterface(width:1.5.w,height:3.5.h,left:23.w,top:3.h,),"6:544":PixFlutterInterface(width:5.5.w,height:5.5.w,left:28.w,top:0.h,),"6:545":PixFlutterInterface(width:4.5.w,height:4.5.w,left:0.5.w,top:0.5.h,),"6:546":PixFlutterInterface(width:5.5.w,height:5.5.w,left:0.w,top:0.h,),"6:547":PixFlutterInterface(width:5.5.w,height:5.5.w,left:21.w,top:0.h,),"6:548":PixFlutterInterface(width:5.5.w,height:5.5.w,left:14.w,top:0.h,),"6:549":PixFlutterInterface(width:5.5.w,height:5.5.w,left:7.w,top:0.h,),"6:550":PixFlutterInterface(width:5.5.w,height:5.5.w,left:0.w,top:0.h,),}, false),
                  ],),),
              ],
            )
          )
        
      ),
      
      
    );
  }
}
