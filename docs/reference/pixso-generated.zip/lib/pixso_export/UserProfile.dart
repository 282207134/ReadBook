import 'package:flutter/material.dart';
import 'package:flutter_ui/utils/pix_adapted_screen.dart';
import 'package:flutter_ui/components/Group.dart';
import 'package:flutter_ui/utils/pix_flutter_interface.dart';

class UserProfile extends StatefulWidget {

  UserProfile({super.key,});
  @override
  State<UserProfile> createState() => _UserProfileState();
}

class _UserProfileState extends State<UserProfile> {


  @override
  void initState() {
    super.initState();
  
  }


  @override
  Widget build(BuildContext context) {
    ScreenUtil().rootSize = Size(375, 667);
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: MediaQuery.removePadding(
        context: context,
        removeTop: true,
        removeBottom: true,
        child: SizedBox(
            width: 375.w,
            height: 667.h,
            child: ListView(
              children: [
                Container(
                width: 375.w,
                height: 667.h,
                decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                clipBehavior: Clip.hardEdge,
                child: Stack(
                  key: ValueKey("8:71"),
                  children: [
                    Positioned(
                      width: 375.w,
                      height: 50.h,
                      left: 0.w,
                      top: 314.h,
                      child: Container(
                        key: ValueKey("95:248"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, 0.w),blurRadius: 5.w,)],),),),
                    Positioned(
                      width: 375.w,
                      height: 50.h,
                      left: 0.w,
                      top: 264.h,
                      child: Container(
                        key: ValueKey("95:247"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, 0.w),blurRadius: 5.w,)],),),),
                    Positioned(
                      width: 375.w,
                      height: 50.h,
                      left: 0.w,
                      top: 214.h,
                      child: Container(
                        key: ValueKey("95:246"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, 0.w),blurRadius: 5.w,)],),),),
                    Positioned(
                      width: 375.w,
                      height: 50.h,
                      left: 0.w,
                      top: 114.h,
                      child: Container(
                        key: ValueKey("95:244"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, 0.w),blurRadius: 5.w,)],),),),
                    Positioned(
                      width: 375.w,
                      height: 50.h,
                      left: 0.w,
                      top: 164.h,
                      child: Container(
                        key: ValueKey("95:245"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, 0.w),blurRadius: 5.w,)],),),),
                    Positioned(
                      width: 375.w,
                      height: 50.h,
                      left: 0.w,
                      top: 64.h,
                      child: Container(
                        key: ValueKey("95:242"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, 0.w),blurRadius: 5.w,)],),),),
                    Positioned(
                      width: 375.w,
                      height: 64.h,
                      left: 0.w,
                      top: 0.h,
                      child: Container(
                        key: ValueKey("8:72"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, -1.w),blurRadius: 10.w,)],),),),
                    Positioned(
                      width: 53.w,
                      height: 23.h,
                      left: 161.w,
                      top: 29.h,
                      child: Text("Profile",
                        key: ValueKey("8:73"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 17.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 87.w,
                      height: 18.h,
                      left: 16.w,
                      top: 130.h,
                      child: Text("Order History",
                        key: ValueKey("8:143"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.2857142857142858, letterSpacing: 0.w),),),
                    Positioned(
                      width: 69.w,
                      height: 18.h,
                      left: 16.w,
                      top: 180.h,
                      child: Text("My Library",
                        key: ValueKey("8:144"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.2857142857142858, letterSpacing: 0.w),),),
                    Positioned(
                      width: 81.w,
                      height: 18.h,
                      left: 16.w,
                      top: 230.h,
                      child: Text("My Coupons",
                        key: ValueKey("8:145"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.2857142857142858, letterSpacing: 0.w),),),
                    Positioned(
                      width: 87.w,
                      height: 15.h,
                      left: 16.w,
                      top: 82.h,
                      child: Text("My Account",
                        key: ValueKey("8:155"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.0714285714285714, letterSpacing: 0.w),),),
                    Positioned(
                      width: 375.w,
                      height: 50.h,
                      left: 0.w,
                      top: 617.h,
                      child: Container(
                        key: ValueKey("34:105"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, 1.w),blurRadius: 10.w,)],),),),
                    Positioned(
                      width: 22.w,
                      height: 23.h,
                      left: 27.w,
                      top: 630.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("34:106"),
                          children: [
                            Positioned(
                              width: 23.w,
                              height: 24.12.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("34:107"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group78.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 23.w,
                      height: 20.37.h,
                      left: 176.w,
                      top: 633.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("34:109"),
                          children: [
                            Positioned(
                              width: 24.w,
                              height: 21.58.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("34:110"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group77.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 22.w,
                      height: 22.h,
                      left: 102.w,
                      top: 631.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("34:112"),
                          children: [
                            Positioned(
                              width: 22.85.w,
                              height: 22.85.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("34:113"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group76.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 22.w,
                      height: 22.h,
                      left: 252.w,
                      top: 631.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("34:116"),
                          children: [
                            Positioned(
                              width: 23.w,
                              height: 23.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("34:117"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group75.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 22.w,
                      height: 23.57.h,
                      left: 327.w,
                      top: 630.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("34:120"),
                          children: [
                            Positioned(
                              width: 24.w,
                              height: 25.57.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("34:121"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group74.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 10.73.w,
                      height: 18.h,
                      left: 349.w,
                      top: 80.h,
                      child: Image(
                        key: ValueKey("34:124"),
                        image: AssetImage("http://localhost:3667/assets/1793182110309/Vector4.svg.png"),),),
                    Positioned(
                      width: 10.73.w,
                      height: 18.h,
                      left: 349.w,
                      top: 130.h,
                      child: Image(
                        key: ValueKey("34:125"),
                        image: AssetImage("http://localhost:3667/assets/1793182110309/Vector3.svg.png"),),),
                    Positioned(
                      width: 10.73.w,
                      height: 18.h,
                      left: 349.w,
                      top: 180.h,
                      child: Image(
                        key: ValueKey("34:126"),
                        image: AssetImage("http://localhost:3667/assets/1793182110309/Vector2.svg.png"),),),
                    Positioned(
                      width: 10.73.w,
                      height: 18.h,
                      left: 349.w,
                      top: 230.h,
                      child: Image(
                        key: ValueKey("34:127"),
                        image: AssetImage("http://localhost:3667/assets/1793182110309/Vector1.svg.png"),),),
                    Positioned(
                      width: 65.w,
                      height: 18.h,
                      left: 16.w,
                      top: 280.h,
                      child: Text("Need help",
                        key: ValueKey("66:2"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.2857142857142858, letterSpacing: 0.w),),),
                    Positioned(
                      width: 10.73.w,
                      height: 18.h,
                      left: 349.w,
                      top: 280.h,
                      child: Image(
                        key: ValueKey("66:5"),
                        image: AssetImage("http://localhost:3667/assets/1793182110309/Vector0.svg.png"),),),
                    Positioned(
                      width: 93.w,
                      height: 18.h,
                      left: 16.w,
                      top: 330.h,
                      child: Text("About this app",
                        key: ValueKey("66:7"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.2857142857142858, letterSpacing: 0.w),),),
                    Positioned(
                      width: 10.73.w,
                      height: 18.h,
                      left: 349.w,
                      top: 330.h,
                      child: Image(
                        key: ValueKey("66:9"),
                        image: AssetImage("http://localhost:3667/assets/1793182110309/Vector.svg.png"),),),
                    Group({"6:525":PixFlutterInterface(width:31.w,height:16.h,left:304.5.w,top:0.h,),"6:526":PixFlutterInterface(width:24.5.w,height:9.5.h,left:338.5.w,top:3.5.h,),"6:527":PixFlutterInterface(width:22.5.w,height:9.5.h,left:0.w,top:0.h,),"6:528":PixFlutterInterface(width:22.5.w,height:9.5.h,left:0.w,top:0.h,),"6:529":PixFlutterInterface(width:21.5.w,height:8.5.h,left:0.5.w,top:0.5.h,),"6:530":PixFlutterInterface(width:22.5.w,height:9.5.h,left:0.w,top:0.h,),"6:531":PixFlutterInterface(width:20.5.w,height:7.5.h,left:1.w,top:1.h,),"6:532":PixFlutterInterface(width:1.5.w,height:3.5.h,left:23.w,top:3.h,),"6:542":PixFlutterInterface(width:48.w,height:16.h,left:157.w,top:1.h,),"6:543":PixFlutterInterface(width:33.5.w,height:5.5.h,left:0.w,top:5.5.h,),"6:544":PixFlutterInterface(width:5.5.w,height:5.5.w,left:28.w,top:0.h,),"6:545":PixFlutterInterface(width:4.5.w,height:4.5.w,left:0.5.w,top:0.5.h,),"6:546":PixFlutterInterface(width:5.5.w,height:5.5.w,left:0.w,top:0.h,),"6:547":PixFlutterInterface(width:5.5.w,height:5.5.w,left:21.w,top:0.h,),"6:548":PixFlutterInterface(width:5.5.w,height:5.5.w,left:14.w,top:0.h,),"6:549":PixFlutterInterface(width:5.5.w,height:5.5.w,left:7.w,top:0.h,),"6:550":PixFlutterInterface(width:5.5.w,height:5.5.w,left:0.w,top:0.h,),"96:52":PixFlutterInterface(width:363.w,height:17.h,left:6.5.w,top:2.h,),}, false),
                    Positioned(
                      width: 24.w,
                      height: 2.h,
                      left: 327.w,
                      top: 665.h,
                      child: Container(
                        key: ValueKey("36:151"),
                        decoration: BoxDecoration(color: Color.fromRGBO(50, 205, 119,1),border: Border.all(width: 1.w, color: Colors.transparent, ),),),),
                  ],),),
              ],
            )
          )
        
      ),
      
      
    );
  }
}
