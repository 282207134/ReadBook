import 'package:flutter/material.dart';
import 'package:flutter_ui/utils/pix_adapted_screen.dart';
import 'package:flutter_ui/custom_widget/CustomWidget_95_249.dart';
import 'package:flutter_ui/components/Group.dart';
import 'package:flutter_ui/utils/pix_flutter_interface.dart';

class Home extends StatefulWidget {

  Home({super.key,});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {


  @override
  void initState() {
    super.initState();
  
  }


  @override
  Widget build(BuildContext context) {
    ScreenUtil().rootSize = Size(375, 812);
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: MediaQuery.removePadding(
        context: context,
        removeTop: true,
        removeBottom: true,
        child: SizedBox(
            width: 375.w,
            height: 812.h,
            child: ListView(
              children: [
                Container(
                width: 375.w,
                height: 957.h,
                decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                clipBehavior: Clip.hardEdge,
                child: Stack(
                  key: ValueKey("4:42"),
                  children: [
                    Positioned(
                      width: 120.w,
                      height: 187.h,
                      left: 16.w,
                      top: 127.h,
                      child: Container(
                        key: ValueKey("14:51"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),borderRadius: BorderRadius.circular(4.h),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.2),offset: Offset(0.w, 10.w),blurRadius: 20.w,)],),),),
                    Positioned(
                      width: 120.w,
                      height: 187.h,
                      left: 156.w,
                      top: 127.h,
                      child: Container(
                        key: ValueKey("14:52"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),borderRadius: BorderRadius.circular(4.h),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.2),offset: Offset(0.w, 10.w),blurRadius: 20.w,)],),),),
                    Positioned(
                      width: 120.w,
                      height: 187.h,
                      left: 296.w,
                      top: 127.h,
                      child: Container(
                        key: ValueKey("14:53"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),borderRadius: BorderRadius.circular(4.h),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.2),offset: Offset(0.w, 10.w),blurRadius: 20.w,)],),),),
                    Positioned(
                      width: 375.w,
                      height: 64.h,
                      left: 0.w,
                      top: 0.h,
                      child: Container(
                        key: ValueKey("4:53"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, 0.w),blurRadius: 10.w,)],),),),
                    Positioned(
                      width: 131.w,
                      height: 21.h,
                      left: 16.w,
                      top: 91.h,
                      child: Text("Top New Releases",
                        key: ValueKey("4:56"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 15.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 56.w,
                      height: 16.h,
                      left: 302.w,
                      top: 95.h,
                      child: Text("View all".toUpperCase(),
                        key: ValueKey("4:57"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(3, 150, 255,1), fontFamily: "Circular Std", fontWeight: FontWeight.w500, fontSize: 11.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 100.w,
                      height: 18.h,
                      left: 15.w,
                      top: 326.h,
                      child: Text("The Mars Room",
                        key: ValueKey("4:59"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.2857142857142858, letterSpacing: 0.w),),),
                    Positioned(
                      width: 94.w,
                      height: 16.h,
                      left: 15.w,
                      top: 348.h,
                      child: Text("by Steven Curran",
                        key: ValueKey("4:60"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(167, 167, 177,1), fontFamily: "Circular Std", fontSize: 11.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 42.w,
                      height: 18.h,
                      left: 15.w,
                      top: 367.h,
                      child: Text("\$10.55",
                        key: ValueKey("36:30"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(50, 205, 119,1), fontFamily: "Circular Std", fontWeight: FontWeight.bold, fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 114.w,
                      height: 18.h,
                      left: 156.w,
                      top: 326.h,
                      child: Text("How to Stop Time",
                        key: ValueKey("13:16"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.2857142857142858, letterSpacing: 0.w),),),
                    Positioned(
                      width: 71.w,
                      height: 16.h,
                      left: 156.w,
                      top: 348.h,
                      child: Text("by Matt Haig",
                        key: ValueKey("13:17"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(167, 167, 177,1), fontFamily: "Circular Std", fontSize: 11.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 41.w,
                      height: 18.h,
                      left: 156.w,
                      top: 367.h,
                      child: Text("\$20.12",
                        key: ValueKey("13:18"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(50, 205, 119,1), fontFamily: "Circular Std", fontWeight: FontWeight.bold, fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 87.w,
                      height: 18.h,
                      left: 296.w,
                      top: 326.h,
                      child: Text("Blue Highway",
                        key: ValueKey("13:19"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.2857142857142858, letterSpacing: 0.w),),),
                    Positioned(
                      width: 98.w,
                      height: 16.h,
                      left: 296.w,
                      top: 348.h,
                      child: Text("by Steven Holzner",
                        key: ValueKey("13:20"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(167, 167, 177,1), fontFamily: "Circular Std", fontSize: 11.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 43.w,
                      height: 18.h,
                      left: 296.w,
                      top: 367.h,
                      child: Text("\$18.99",
                        key: ValueKey("13:21"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(50, 205, 119,1), fontFamily: "Circular Std", fontWeight: FontWeight.bold, fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 120.w,
                      height: 187.h,
                      left: 156.w,
                      top: 127.h,
                      child: Container(
                        clipBehavior: Clip.hardEdge,
                        decoration: BoxDecoration(),
                        child: Image(
                          key: ValueKey("13:15"),
                          image: AssetImage("http://localhost:3667/assets/1793182110309/MaskGroup.png.png"),),),),
                    Positioned(
                      width: 120.w,
                      height: 187.h,
                      left: 16.w,
                      top: 127.h,
                      child: Container(
                        clipBehavior: Clip.hardEdge,
                        decoration: BoxDecoration(),
                        child: Image(
                          key: ValueKey("89:7"),
                          image: AssetImage("http://localhost:3667/assets/1793182110309/MaskGroup.png.png"),),),),
                    Positioned(
                      width: 120.w,
                      height: 187.h,
                      left: 296.w,
                      top: 127.h,
                      child: Container(
                        clipBehavior: Clip.hardEdge,
                        decoration: BoxDecoration(),
                        child: Image(
                          key: ValueKey("13:24"),
                          image: AssetImage("http://localhost:3667/assets/1793182110309/MaskGroup.png.png"),),),),
                    Positioned(
                      width: 120.w,
                      height: 187.h,
                      left: 16.w,
                      top: 613.h,
                      child: Container(
                        key: ValueKey("89:43"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),borderRadius: BorderRadius.circular(4.h),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.2),offset: Offset(0.w, 10.w),blurRadius: 20.w,)],),),),
                    Positioned(
                      width: 120.w,
                      height: 187.h,
                      left: 156.w,
                      top: 613.h,
                      child: Container(
                        key: ValueKey("89:44"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),borderRadius: BorderRadius.circular(4.h),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.2),offset: Offset(0.w, 10.w),blurRadius: 20.w,)],),),),
                    Positioned(
                      width: 120.w,
                      height: 187.h,
                      left: 296.w,
                      top: 613.h,
                      child: Container(
                        key: ValueKey("89:45"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),borderRadius: BorderRadius.circular(4.h),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.2),offset: Offset(0.w, 10.w),blurRadius: 20.w,)],),),),
                    Positioned(
                      width: 131.w,
                      height: 21.h,
                      left: 16.w,
                      top: 577.h,
                      child: Text("Top New Releases",
                        key: ValueKey("89:46"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 15.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 56.w,
                      height: 16.h,
                      left: 302.w,
                      top: 581.h,
                      child: Text("View all".toUpperCase(),
                        key: ValueKey("89:47"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(3, 150, 255,1), fontFamily: "Circular Std", fontWeight: FontWeight.w500, fontSize: 11.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 112.w,
                      height: 18.h,
                      left: 15.w,
                      top: 812.h,
                      child: Text("Hardwiring Hap...",
                        key: ValueKey("89:48"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.2857142857142858, letterSpacing: 0.w),),),
                    Positioned(
                      width: 84.w,
                      height: 16.h,
                      left: 15.w,
                      top: 834.h,
                      child: Text("by Rick Hanson",
                        key: ValueKey("89:49"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(167, 167, 177,1), fontFamily: "Circular Std", fontSize: 11.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 39.w,
                      height: 18.h,
                      left: 15.w,
                      top: 853.h,
                      child: Text("\$17.25",
                        key: ValueKey("89:50"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(50, 205, 119,1), fontFamily: "Circular Std", fontWeight: FontWeight.bold, fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 106.w,
                      height: 18.h,
                      left: 156.w,
                      top: 812.h,
                      child: Text("The Benefits of...",
                        key: ValueKey("89:51"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.2857142857142858, letterSpacing: 0.w),),),
                    Positioned(
                      width: 80.w,
                      height: 16.h,
                      left: 156.w,
                      top: 834.h,
                      child: Text("by Ann Braden",
                        key: ValueKey("89:52"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(167, 167, 177,1), fontFamily: "Circular Std", fontSize: 11.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 43.w,
                      height: 18.h,
                      left: 156.w,
                      top: 853.h,
                      child: Text("\$16.95 ",
                        key: ValueKey("89:53"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(50, 205, 119,1), fontFamily: "Circular Std", fontWeight: FontWeight.bold, fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 114.w,
                      height: 18.h,
                      left: 296.w,
                      top: 812.h,
                      child: Text("Teaspoon of Earth",
                        key: ValueKey("89:54"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.2857142857142858, letterSpacing: 0.w),),),
                    Positioned(
                      width: 70.w,
                      height: 16.h,
                      left: 296.w,
                      top: 834.h,
                      child: Text("by Dina Nayr",
                        key: ValueKey("89:55"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(167, 167, 177,1), fontFamily: "Circular Std", fontSize: 11.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 44.w,
                      height: 18.h,
                      left: 296.w,
                      top: 853.h,
                      child: Text("\$24.70 ",
                        key: ValueKey("89:56"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(50, 205, 119,1), fontFamily: "Circular Std", fontWeight: FontWeight.bold, fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 120.w,
                      height: 187.h,
                      left: 156.w,
                      top: 613.h,
                      child: Container(
                        clipBehavior: Clip.hardEdge,
                        decoration: BoxDecoration(),
                        child: Image(
                          key: ValueKey("89:57"),
                          image: AssetImage("http://localhost:3667/assets/1793182110309/MaskGroup.png.png"),),),),
                    Positioned(
                      width: 120.w,
                      height: 187.h,
                      left: 16.w,
                      top: 613.h,
                      child: Container(
                        clipBehavior: Clip.hardEdge,
                        decoration: BoxDecoration(),
                        child: Image(
                          key: ValueKey("89:60"),
                          image: AssetImage("http://localhost:3667/assets/1793182110309/MaskGroup.png.png"),),),),
                    Positioned(
                      width: 120.w,
                      height: 187.h,
                      left: 296.w,
                      top: 613.h,
                      child: Container(
                        clipBehavior: Clip.hardEdge,
                        decoration: BoxDecoration(),
                        child: Image(
                          key: ValueKey("89:63"),
                          image: AssetImage("http://localhost:3667/assets/1793182110309/MaskGroup.png.png"),),),),
                    Positioned(
                      width: 110.w,
                      height: 21.h,
                      left: 16.w,
                      top: 418.h,
                      child: Text("Top Categories",
                        key: ValueKey("4:68"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 15.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 56.w,
                      height: 16.h,
                      left: 304.w,
                      top: 421.h,
                      child: Text("View all".toUpperCase(),
                        key: ValueKey("4:69"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(3, 150, 255,1), fontFamily: "Circular Std", fontWeight: FontWeight.w500, fontSize: 11.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 144.w,
                      height: 88.h,
                      left: 16.w,
                      top: 454.h,
                      child: Container(
                        key: ValueKey("94:12"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),borderRadius: BorderRadius.circular(4.h),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.2),offset: Offset(0.w, 10.w),blurRadius: 20.w,)],),),),
                    Positioned(
                      width: 144.w,
                      height: 88.h,
                      left: 172.w,
                      top: 454.h,
                      child: Container(
                        key: ValueKey("94:13"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),borderRadius: BorderRadius.circular(4.h),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.2),offset: Offset(0.w, 10.w),blurRadius: 20.w,)],),),),
                    Positioned(
                      width: 144.w,
                      height: 88.h,
                      left: 328.w,
                      top: 454.h,
                      child: Container(
                        key: ValueKey("94:14"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),borderRadius: BorderRadius.circular(4.h),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.2),offset: Offset(0.w, 10.w),blurRadius: 20.w,)],),),),
                    Positioned(
                      width: 144.w,
                      height: 88.h,
                      left: 16.w,
                      top: 454.h,
                      child: Container(
                        key: ValueKey("4:70"),
                        decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment(0,0), end: Alignment(1.0000000277777776,1.0000000340909092), colors: [Color.fromRGBO(226, 176, 255,1), Color.fromRGBO(159, 68, 211,1)], stops: [0, 1]),borderRadius: BorderRadius.circular(4.h),border: Border.all(width: 1.w, color: Colors.transparent, ),),),),
                    Positioned(
                      width: 144.w,
                      height: 88.h,
                      left: 172.w,
                      top: 454.h,
                      child: Container(
                        key: ValueKey("4:85"),
                        decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment(0,0), end: Alignment(1.0000000277777776,1.0000000340909092), colors: [Color.fromRGBO(171, 220, 255,1), Color.fromRGBO(3, 150, 255,1)], stops: [0, 1]),borderRadius: BorderRadius.circular(4.h),border: Border.all(width: 1.w, color: Colors.transparent, ),),),),
                    Positioned(
                      width: 136.w,
                      height: 88.h,
                      left: 328.w,
                      top: 454.h,
                      child: Container(
                        key: ValueKey("4:86"),
                        decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment(0,0), end: Alignment(1.0000000294117646,1.0000000340909092), colors: [Color.fromRGBO(254, 182, 146,1), Color.fromRGBO(234, 84, 85,1)], stops: [0, 1]),borderRadius: BorderRadius.circular(4.h),border: Border.all(width: 1.w, color: Colors.transparent, ),),),),
                    Positioned(
                      width: 46.w,
                      height: 19.h,
                      left: 65.w,
                      top: 489.h,
                      child: Text("Drama",
                        key: ValueKey("4:87"),
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Color.fromRGBO(255, 255, 255,1), fontFamily: "Circular Std", fontWeight: FontWeight.w500, fontSize: 14.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 89.w,
                      height: 19.h,
                      left: 200.w,
                      top: 489.h,
                      child: Text("Photography",
                        key: ValueKey("4:88"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(255, 255, 255,1), fontFamily: "Circular Std", fontWeight: FontWeight.w500, fontSize: 14.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 18.w,
                      height: 18.9.h,
                      left: 340.w,
                      top: 32.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("34:197"),
                          children: [
                            Positioned(
                              width: 20.w,
                              height: 21.52.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("34:198"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group73.svg.png"),),),),
                          ],),),),
                    CustomWidget_95_249(),
                    Positioned(
                      width: 136.w,
                      height: 23.h,
                      left: 120.w,
                      top: 29.h,
                      child: Text("Venus Bookstore",
                        key: ValueKey("36:155"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 17.6.sp, letterSpacing: 0.w),),),
                    Group({"6:525":PixFlutterInterface(textColor:Color.fromRGBO(34, 34, 59,1),width:31.w,height:16.h,left:304.5.w,top:0.h,),"6:526":PixFlutterInterface(backgroundColor:Color.fromRGBO(34, 34, 59,1),width:24.5.w,height:9.5.h,left:338.5.w,top:3.5.h,),"6:542":PixFlutterInterface(textColor:Color.fromRGBO(34, 34, 59,1),width:48.w,height:16.h,left:157.w,top:1.h,),"6:543":PixFlutterInterface(backgroundColor:Color.fromRGBO(34, 34, 59,1),width:33.5.w,height:5.5.h,left:0.w,top:5.5.h,),"96:52":PixFlutterInterface(width:363.w,height:17.h,left:6.5.w,top:2.h,),"6:527":PixFlutterInterface(width:22.5.w,height:9.5.h,left:0.w,top:0.h,),"6:528":PixFlutterInterface(width:22.5.w,height:9.5.h,left:0.w,top:0.h,),"6:529":PixFlutterInterface(width:21.5.w,height:8.5.h,left:0.5.w,top:0.5.h,),"6:530":PixFlutterInterface(width:22.5.w,height:9.5.h,left:0.w,top:0.h,),"6:531":PixFlutterInterface(width:20.5.w,height:7.5.h,left:1.w,top:1.h,),"6:532":PixFlutterInterface(width:1.5.w,height:3.5.h,left:23.w,top:3.h,),"6:544":PixFlutterInterface(width:5.5.w,height:5.5.w,left:28.w,top:0.h,),"6:545":PixFlutterInterface(width:4.5.w,height:4.5.w,left:0.5.w,top:0.5.h,),"6:546":PixFlutterInterface(width:5.5.w,height:5.5.w,left:0.w,top:0.h,),"6:547":PixFlutterInterface(width:5.5.w,height:5.5.w,left:21.w,top:0.h,),"6:548":PixFlutterInterface(width:5.5.w,height:5.5.w,left:14.w,top:0.h,),"6:549":PixFlutterInterface(width:5.5.w,height:5.5.w,left:7.w,top:0.h,),"6:550":PixFlutterInterface(width:5.5.w,height:5.5.w,left:0.w,top:0.h,),}, false),
                  ],),),
              ],
            )
          )
        
      ),
      
      
    );
  }
}
