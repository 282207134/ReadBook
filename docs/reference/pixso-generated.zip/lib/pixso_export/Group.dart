import 'package:flutter/material.dart';
import 'package:flutter_ui/utils/pix_adapted_screen.dart';
import 'package:flutter_ui/utils/pix_flutter_interface.dart';
import 'package:flutter_ui/utils/pix_extensions.dart';

class Group extends StatefulWidget {
  Map<dynamic, PixFlutterInterface> datas;
  bool isAutoLayout;
  Map? propMap;
  Group(this.datas,this.isAutoLayout,{super.key,this.propMap,});
  @override
  State<Group> createState() => _GroupState();
}

class _GroupState extends State<Group> {


  @override
  void initState() {
    super.initState();
  
  }

  PixFlutterInterface? _getPropValueById(String id) {
    return widget.datas[id];
  }

  @override
  Widget build(BuildContext context) {
    Widget child = Visibility(
      visible: _getPropValueById('96:52')?.visible ?? true,
      child: Container(
        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),).copyWithInterface(_getPropValueById('96:52')),
        child: Opacity(
          opacity: _getPropValueById('96:52')?.opacity ?? 0.3,
          child: Stack(
            key: ValueKey("96:52"),
            clipBehavior: Clip.none,
            children: [
              Positioned(
                width: 31.w,
                height: 16.h,
                left: 304.5.w,
                top: 0.h,
                child: Text("100%",
                  key: ValueKey("6:525"),
                  textAlign: TextAlign.right,
                  style: TextStyle(color: Color.fromRGBO(34, 34, 59,1), fontFamily: "SF UI Text", fontSize: 11.6.sp, height: 1.3333333333333333, letterSpacing: 0.w),),),
              Positioned(
                width: 24.5.w,
                height: 9.5.h,
                left: 338.5.w,
                top: 3.5.h,
                child: Image(
                  key: ValueKey("6:526"),
                  image: AssetImage("http://localhost:3667/assets/1793182110309/Battery14.svg.png"),),),
              Positioned(
                width: 48.w,
                height: 16.h,
                left: 157.w,
                top: 1.h,
                child: Text("1:20 PM",
                  key: ValueKey("6:542"),
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Color.fromRGBO(34, 34, 59,1), fontFamily: "SF UI Text", fontWeight: FontWeight.bold, fontSize: 11.6.sp, height: 1.3333333333333333, letterSpacing: 0.w),),),
              Positioned(
                width: 33.5.w,
                height: 5.5.h,
                left: 0.w,
                top: 5.5.h,
                child: Image(
                  key: ValueKey("6:543"),
                  image: AssetImage("http://localhost:3667/assets/1793182110309/Signal14.svg.png"),),),
            ],),),),);
    return widget.isAutoLayout == true
      ? SizedBox(
          width: _getPropValueById('96:52')?.width ?? 363.w,
          height: _getPropValueById('96:52')?.height ?? 17.h,
          child: child
        )
      : Positioned(
          width: _getPropValueById('96:52')?.width ?? 363.w,
          height: _getPropValueById('96:52')?.height ?? 17.h,
          left: _getPropValueById('96:52')?.left ?? 6.5.w,
          top: _getPropValueById('96:52')?.top ?? 2.h,
          child: child
        );
  }
}
