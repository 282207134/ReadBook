import 'package:flutter/material.dart';
import 'package:flutter_ui/utils/pix_adapted_screen.dart';
import 'package:flutter_ui/components/Group.dart';
import 'package:flutter_ui/utils/pix_flutter_interface.dart';

class BillingPayment extends StatefulWidget {

  BillingPayment({super.key,});
  @override
  State<BillingPayment> createState() => _BillingPaymentState();
}

class _BillingPaymentState extends State<BillingPayment> {


  @override
  void initState() {
    super.initState();
  
  }


  @override
  Widget build(BuildContext context) {
    ScreenUtil().rootSize = Size(375, 667);
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: MediaQuery.removePadding(
        context: context,
        removeTop: true,
        removeBottom: true,
        child: SizedBox(
            width: 375.w,
            height: 667.h,
            child: ListView(
              children: [
                Container(
                width: 375.w,
                height: 667.h,
                decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                clipBehavior: Clip.hardEdge,
                child: Stack(
                  key: ValueKey("6:409"),
                  children: [
                    Positioned(
                      width: 375.w,
                      height: 59.h,
                      left: 0.w,
                      top: 123.h,
                      child: Container(
                        key: ValueKey("95:236"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, 0.w),blurRadius: 5.w,)],),),),
                    Positioned(
                      width: 375.w,
                      height: 58.h,
                      left: 0.w,
                      top: 64.h,
                      child: Container(
                        key: ValueKey("34:7"),
                        decoration: BoxDecoration(color: Color.fromRGBO(248, 248, 248,1),border: Border.all(width: 1.w, color: Colors.transparent, ),),),),
                    Positioned(
                      width: 375.w,
                      height: 64.h,
                      left: 0.w,
                      top: 0.h,
                      child: Container(
                        key: ValueKey("6:410"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, -1.w),blurRadius: 10.w,)],),),),
                    Positioned(
                      width: 160.w,
                      height: 23.h,
                      left: 108.w,
                      top: 29.h,
                      child: Text("Billing and Payment",
                        key: ValueKey("6:411"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 17.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 75.w,
                      height: 18.h,
                      left: 48.w,
                      top: 84.h,
                      child: Text("Credit Card",
                        key: ValueKey("6:439"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 48.w,
                      height: 14.67.h,
                      left: 311.w,
                      top: 87.h,
                      child: Container(
                        key: ValueKey("35:3"),
                        decoration: BoxDecoration(image: DecorationImage(image: AssetImage("assets/images/587b60640c366ff505e9a44db70ef4200026f07c.png"), fit: BoxFit.cover),border: Border.all(width: 1.w, color: Colors.transparent, ),),),),
                    Positioned(
                      width: 64.w,
                      height: 17.29.h,
                      left: 295.w,
                      top: 145.h,
                      child: Container(
                        key: ValueKey("36:0"),
                        decoration: BoxDecoration(image: DecorationImage(image: AssetImage("assets/images/ec511092ef6f558974db0964424a2a62583e0f32.png"), fit: BoxFit.cover),border: Border.all(width: 1.w, color: Colors.transparent, ),),),),
                    Positioned(
                      width: 343.w,
                      height: 46.h,
                      left: 16.w,
                      top: 605.h,
                      child: Container(
                        key: ValueKey("6:441"),
                        decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment(0,0), end: Alignment(1.0000000291545188,1.0000000217391303), colors: [Color.fromRGBO(129, 251, 184,1), Color.fromRGBO(40, 199, 111,1)], stops: [0, 1]),borderRadius: BorderRadius.circular(4.h),border: Border.all(width: 1.w, color: Colors.transparent, ),),),),
                    Positioned(
                      width: 83.w,
                      height: 20.h,
                      left: 146.w,
                      top: 618.h,
                      child: Text("Place Order",
                        key: ValueKey("6:442"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(255, 255, 255,1), fontFamily: "Circular Std", fontWeight: FontWeight.bold, fontSize: 14.6.sp, height: 1.3333333333333333, letterSpacing: 0.w),),),
                    Positioned(
                      width: 20.w,
                      height: 20.h,
                      left: 16.w,
                      top: 83.h,
                      child: Image(
                        key: ValueKey("6:443"),
                        image: AssetImage("http://localhost:3667/assets/1793182110309/Ellipse10.svg.png"),),),
                    Positioned(
                      width: 10.w,
                      height: 10.h,
                      left: 21.w,
                      top: 88.h,
                      child: Image(
                        key: ValueKey("34:4"),
                        image: AssetImage("http://localhost:3667/assets/1793182110309/Ellipse9.svg.png"),),),
                    Positioned(
                      width: 42.w,
                      height: 18.h,
                      left: 48.w,
                      top: 143.h,
                      child: Text("Paypal",
                        key: ValueKey("6:444"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 20.w,
                      height: 20.h,
                      left: 16.w,
                      top: 142.h,
                      child: Image(
                        key: ValueKey("6:446"),
                        image: AssetImage("http://localhost:3667/assets/1793182110309/Ellipse8.svg.png"),),),
                    Positioned(
                      width: 86.w,
                      height: 18.h,
                      left: 15.w,
                      top: 215.h,
                      child: Text("Number Card",
                        key: ValueKey("6:453"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 343.w,
                      height: 44.h,
                      left: 16.w,
                      top: 241.h,
                      child: Container(
                        key: ValueKey("6:454"),
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Color.fromRGBO(226, 226, 226,1), ),),),),
                    Positioned(
                      width: 72.w,
                      height: 18.h,
                      left: 15.w,
                      top: 305.h,
                      child: Text("Name Card",
                        key: ValueKey("6:455"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 343.w,
                      height: 44.h,
                      left: 16.w,
                      top: 331.h,
                      child: Container(
                        key: ValueKey("6:456"),
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Color.fromRGBO(226, 226, 226,1), ),),),),
                    Positioned(
                      width: 73.w,
                      height: 18.h,
                      left: 15.w,
                      top: 395.h,
                      child: Text("Expiry Date",
                        key: ValueKey("6:457"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 27.w,
                      height: 18.h,
                      left: 28.w,
                      top: 434.h,
                      child: Text("MM",
                        key: ValueKey("6:459"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(167, 167, 177,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 76.w,
                      height: 44.h,
                      left: 16.w,
                      top: 421.h,
                      child: Container(
                        key: ValueKey("6:458"),
                        decoration: BoxDecoration(borderRadius: BorderRadius.circular(4.h),border: Border.all(width: 1.w, color: Color.fromRGBO(226, 226, 226,1), ),),),),
                    Positioned(
                      width: 10.w,
                      height: 7.5.h,
                      left: 69.w,
                      top: 439.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("33:171"),
                          children: [
                            Positioned(
                              width: 10.w,
                              height: 7.5.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("33:172"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group66.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 10.w,
                      height: 7.5.h,
                      left: 154.w,
                      top: 439.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("33:174"),
                          children: [
                            Positioned(
                              width: 10.w,
                              height: 7.5.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("33:175"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group67.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 18.w,
                      height: 18.h,
                      left: 121.w,
                      top: 434.h,
                      child: Text("YY",
                        key: ValueKey("6:460"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(167, 167, 177,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 73.w,
                      height: 44.h,
                      left: 108.w,
                      top: 421.h,
                      child: Container(
                        key: ValueKey("6:461"),
                        decoration: BoxDecoration(borderRadius: BorderRadius.circular(4.h),border: Border.all(width: 1.w, color: Color.fromRGBO(226, 226, 226,1), ),),),),
                    Positioned(
                      width: 29.w,
                      height: 18.h,
                      left: 213.w,
                      top: 395.h,
                      child: Text("CVV",
                        key: ValueKey("6:462"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 65.w,
                      height: 44.h,
                      left: 213.w,
                      top: 421.h,
                      child: Container(
                        key: ValueKey("6:464"),
                        decoration: BoxDecoration(borderRadius: BorderRadius.circular(4.h),border: Border.all(width: 1.w, color: Color.fromRGBO(226, 226, 226,1), ),),),),
                    Positioned(
                      width: 12.01.w,
                      height: 20.h,
                      left: 15.38.w,
                      top: 30.h,
                      child: Image(
                        key: ValueKey("38:51"),
                        image: AssetImage("http://localhost:3667/assets/1793182110309/BackArrowStroke4.svg.png"),),),
                    Group({"6:525":PixFlutterInterface(textColor:Color.fromRGBO(34, 34, 59,1),width:31.w,height:16.h,left:304.5.w,top:0.h,),"6:526":PixFlutterInterface(backgroundColor:Color.fromRGBO(34, 34, 59,1),width:24.5.w,height:9.5.h,left:338.5.w,top:3.5.h,),"6:542":PixFlutterInterface(textColor:Color.fromRGBO(34, 34, 59,1),width:48.w,height:16.h,left:157.w,top:1.h,),"6:543":PixFlutterInterface(backgroundColor:Color.fromRGBO(34, 34, 59,1),width:33.5.w,height:5.5.h,left:0.w,top:5.5.h,),"96:52":PixFlutterInterface(width:363.w,height:17.h,left:6.5.w,top:2.h,),"6:527":PixFlutterInterface(width:22.5.w,height:9.5.h,left:0.w,top:0.h,),"6:528":PixFlutterInterface(width:22.5.w,height:9.5.h,left:0.w,top:0.h,),"6:529":PixFlutterInterface(width:21.5.w,height:8.5.h,left:0.5.w,top:0.5.h,),"6:530":PixFlutterInterface(width:22.5.w,height:9.5.h,left:0.w,top:0.h,),"6:531":PixFlutterInterface(width:20.5.w,height:7.5.h,left:1.w,top:1.h,),"6:532":PixFlutterInterface(width:1.5.w,height:3.5.h,left:23.w,top:3.h,),"6:544":PixFlutterInterface(width:5.5.w,height:5.5.w,left:28.w,top:0.h,),"6:545":PixFlutterInterface(width:4.5.w,height:4.5.w,left:0.5.w,top:0.5.h,),"6:546":PixFlutterInterface(width:5.5.w,height:5.5.w,left:0.w,top:0.h,),"6:547":PixFlutterInterface(width:5.5.w,height:5.5.w,left:21.w,top:0.h,),"6:548":PixFlutterInterface(width:5.5.w,height:5.5.w,left:14.w,top:0.h,),"6:549":PixFlutterInterface(width:5.5.w,height:5.5.w,left:7.w,top:0.h,),"6:550":PixFlutterInterface(width:5.5.w,height:5.5.w,left:0.w,top:0.h,),}, false),
                  ],),),
              ],
            )
          )
        
      ),
      
      
    );
  }
}
