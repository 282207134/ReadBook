import 'package:flutter/material.dart';
import 'package:flutter_ui/utils/pix_adapted_screen.dart';
import 'package:flutter_ui/components/Group.dart';
import 'package:flutter_ui/utils/pix_flutter_interface.dart';

class Cart extends StatefulWidget {

  Cart({super.key,});
  @override
  State<Cart> createState() => _CartState();
}

class _CartState extends State<Cart> {


  @override
  void initState() {
    super.initState();
  
  }


  @override
  Widget build(BuildContext context) {
    ScreenUtil().rootSize = Size(375, 667);
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: MediaQuery.removePadding(
        context: context,
        removeTop: true,
        removeBottom: true,
        child: SizedBox(
            width: 375.w,
            height: 667.h,
            child: ListView(
              children: [
                Container(
                width: 375.w,
                height: 667.h,
                decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                clipBehavior: Clip.hardEdge,
                child: Stack(
                  key: ValueKey("6:177"),
                  children: [
                    Positioned(
                      width: 375.w,
                      height: 50.h,
                      left: 0.w,
                      top: 64.h,
                      child: Container(
                        key: ValueKey("51:13"),
                        decoration: BoxDecoration(color: Color.fromRGBO(249, 249, 249,1),border: Border.all(width: 1.w, color: Colors.transparent, ),),),),
                    Positioned(
                      width: 375.w,
                      height: 64.h,
                      left: 0.w,
                      top: 0.h,
                      child: Container(
                        key: ValueKey("6:178"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, -1.w),blurRadius: 10.w,)],),),),
                    Positioned(
                      width: 37.w,
                      height: 23.h,
                      left: 169.w,
                      top: 29.h,
                      child: Text("Cart",
                        key: ValueKey("6:179"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 17.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 328.w,
                      height: 18.h,
                      left: 16.w,
                      top: 80.h,
                      child: Text("You have 2 items for a total of \$82.44 in your basket.",
                        key: ValueKey("6:231"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 343.w,
                      height: 46.h,
                      left: 16.w,
                      top: 555.h,
                      child: Container(
                        key: ValueKey("6:265"),
                        decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment(0,0), end: Alignment(1.0000000291545188,1.0000000217391303), colors: [Color.fromRGBO(129, 251, 184,1), Color.fromRGBO(40, 199, 111,1)], stops: [0, 1]),borderRadius: BorderRadius.circular(4.h),border: Border.all(width: 1.w, color: Colors.transparent, ),),),),
                    Positioned(
                      width: 144.w,
                      height: 20.h,
                      left: 116.w,
                      top: 568.h,
                      child: Text("Process to Checkout",
                        key: ValueKey("6:266"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(255, 255, 255,1), fontFamily: "Circular Std", fontWeight: FontWeight.bold, fontSize: 14.6.sp, height: 1.3333333333333333, letterSpacing: 0.w),),),
                    Positioned(
                      width: 375.w,
                      height: 50.h,
                      left: 0.w,
                      top: 617.h,
                      child: Container(
                        key: ValueKey("34:178"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, 1.w),blurRadius: 10.w,)],),),),
                    Positioned(
                      width: 22.w,
                      height: 23.h,
                      left: 27.w,
                      top: 630.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("34:179"),
                          children: [
                            Positioned(
                              width: 23.w,
                              height: 24.12.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("34:180"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group57.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 23.w,
                      height: 20.37.h,
                      left: 176.w,
                      top: 633.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("34:182"),
                          children: [
                            Positioned(
                              width: 24.w,
                              height: 21.58.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("34:183"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group56.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 22.w,
                      height: 22.h,
                      left: 102.w,
                      top: 631.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("34:185"),
                          children: [
                            Positioned(
                              width: 22.85.w,
                              height: 22.85.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("34:186"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group55.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 22.w,
                      height: 22.h,
                      left: 252.w,
                      top: 631.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("34:189"),
                          children: [
                            Positioned(
                              width: 24.w,
                              height: 24.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("34:190"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group54.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 22.w,
                      height: 23.57.h,
                      left: 327.w,
                      top: 630.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("34:193"),
                          children: [
                            Positioned(
                              width: 23.w,
                              height: 24.57.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("34:194"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group53.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 24.w,
                      height: 2.h,
                      left: 251.w,
                      top: 665.h,
                      child: Container(
                        key: ValueKey("36:149"),
                        decoration: BoxDecoration(color: Color.fromRGBO(50, 205, 119,1),border: Border.all(width: 1.w, color: Colors.transparent, ),),),),
                    Positioned(
                      width: 12.01.w,
                      height: 20.h,
                      left: 15.38.w,
                      top: 30.h,
                      child: Image(
                        key: ValueKey("38:48"),
                        image: AssetImage("http://localhost:3667/assets/1793182110309/BackArrowStroke3.svg.png"),),),
                    Positioned(
                      width: 375.w,
                      height: 152.h,
                      left: 0.w,
                      top: 267.h,
                      child: Container(
                        key: ValueKey("95:179"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, 0.w),blurRadius: 5.w,)],),),),
                    Positioned(
                      width: 375.w,
                      height: 152.h,
                      left: 0.w,
                      top: 115.h,
                      child: Container(
                        key: ValueKey("95:180"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, 0.w),blurRadius: 5.w,)],),),),
                    Positioned(
                      width: 72.w,
                      height: 112.h,
                      left: 16.w,
                      top: 135.h,
                      child: Container(
                        clipBehavior: Clip.hardEdge,
                        decoration: BoxDecoration(),
                        child: Image(
                          key: ValueKey("95:182"),
                          image: AssetImage("http://localhost:3667/assets/1793182110309/MaskGroup.png.png"),),),),
                    Positioned(
                      width: 114.w,
                      height: 18.h,
                      left: 104.w,
                      top: 165.h,
                      child: Text("How to Stop Time",
                        key: ValueKey("95:186"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.2857142857142858, letterSpacing: 0.w),),),
                    Positioned(
                      width: 94.w,
                      height: 16.h,
                      left: 104.w,
                      top: 187.h,
                      child: Text("by Steven Curran",
                        key: ValueKey("95:187"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(167, 167, 177,1), fontFamily: "Circular Std", fontSize: 11.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 104.w,
                      top: 147.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("95:188"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("95:189"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group50.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 118.w,
                      top: 147.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("95:191"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("95:192"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group49.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 132.w,
                      top: 147.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("95:194"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("95:195"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group48.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 146.w,
                      top: 147.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("95:197"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("95:198"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group52.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 160.w,
                      top: 147.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("95:200"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("95:201"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group51.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 41.w,
                      height: 18.h,
                      left: 318.w,
                      top: 144.h,
                      child: Text("\$20.12",
                        key: ValueKey("95:203"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(50, 205, 119,1), fontFamily: "Circular Std", fontWeight: FontWeight.bold, fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 72.w,
                      height: 112.h,
                      left: 16.w,
                      top: 287.h,
                      child: Container(
                        clipBehavior: Clip.hardEdge,
                        decoration: BoxDecoration(),
                        child: Image(
                          key: ValueKey("95:204"),
                          image: AssetImage("http://localhost:3667/assets/1793182110309/MaskGroup.png.png"),),),),
                    Positioned(
                      width: 140.w,
                      height: 18.h,
                      left: 104.w,
                      top: 317.h,
                      child: Text("Hardwiring Happiness",
                        key: ValueKey("95:208"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.2857142857142858, letterSpacing: 0.w),),),
                    Positioned(
                      width: 94.w,
                      height: 16.h,
                      left: 104.w,
                      top: 339.h,
                      child: Text("by Steven Curran",
                        key: ValueKey("95:209"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(167, 167, 177,1), fontFamily: "Circular Std", fontSize: 11.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 104.w,
                      top: 299.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("95:210"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("95:211"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group47.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 118.w,
                      top: 299.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("95:213"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("95:214"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group46.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 132.w,
                      top: 299.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("95:216"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("95:217"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group45.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 146.w,
                      top: 299.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("95:219"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("95:220"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group44.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 160.w,
                      top: 299.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("95:222"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("95:223"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group43.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 39.w,
                      height: 18.h,
                      left: 320.w,
                      top: 296.h,
                      child: Text("\$17.25",
                        key: ValueKey("95:225"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(50, 205, 119,1), fontFamily: "Circular Std", fontWeight: FontWeight.bold, fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 48.w,
                      height: 16.h,
                      left: 104.w,
                      top: 224.h,
                      child: Text("Quantity",
                        key: ValueKey("33:48"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 11.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 5.w,
                      height: 18.h,
                      left: 175.w,
                      top: 222.h,
                      child: Text("1",
                        key: ValueKey("33:50"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(167, 167, 177,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 61.w,
                      height: 30.h,
                      left: 163.w,
                      top: 217.h,
                      child: Container(
                        key: ValueKey("33:51"),
                        decoration: BoxDecoration(borderRadius: BorderRadius.circular(2.h),border: Border.all(width: 1.w, color: Color.fromRGBO(219, 219, 219,1), ),),),),
                    Positioned(
                      width: 8.w,
                      height: 6.h,
                      left: 203.w,
                      top: 229.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("33:52"),
                          children: [
                            Positioned(
                              width: 8.w,
                              height: 6.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("33:53"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group59.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 48.w,
                      height: 16.h,
                      left: 104.w,
                      top: 376.h,
                      child: Text("Quantity",
                        key: ValueKey("95:226"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 11.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 5.w,
                      height: 18.h,
                      left: 175.w,
                      top: 374.h,
                      child: Text("1",
                        key: ValueKey("95:227"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(167, 167, 177,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 61.w,
                      height: 30.h,
                      left: 163.w,
                      top: 369.h,
                      child: Container(
                        key: ValueKey("95:228"),
                        decoration: BoxDecoration(borderRadius: BorderRadius.circular(2.h),border: Border.all(width: 1.w, color: Color.fromRGBO(219, 219, 219,1), ),),),),
                    Positioned(
                      width: 8.w,
                      height: 6.h,
                      left: 203.w,
                      top: 381.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("95:229"),
                          children: [
                            Positioned(
                              width: 8.w,
                              height: 6.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("95:230"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group58.svg.png"),),),),
                          ],),),),
                    Group({"6:525":PixFlutterInterface(textColor:Color.fromRGBO(34, 34, 59,1),width:31.w,height:16.h,left:304.5.w,top:0.h,),"6:526":PixFlutterInterface(backgroundColor:Color.fromRGBO(34, 34, 59,1),width:24.5.w,height:9.5.h,left:338.5.w,top:3.5.h,),"6:542":PixFlutterInterface(textColor:Color.fromRGBO(34, 34, 59,1),width:48.w,height:16.h,left:157.w,top:1.h,),"6:543":PixFlutterInterface(backgroundColor:Color.fromRGBO(34, 34, 59,1),width:33.5.w,height:5.5.h,left:0.w,top:5.5.h,),"96:52":PixFlutterInterface(width:363.w,height:17.h,left:6.5.w,top:2.h,),"6:527":PixFlutterInterface(width:22.5.w,height:9.5.h,left:0.w,top:0.h,),"6:528":PixFlutterInterface(width:22.5.w,height:9.5.h,left:0.w,top:0.h,),"6:529":PixFlutterInterface(width:21.5.w,height:8.5.h,left:0.5.w,top:0.5.h,),"6:530":PixFlutterInterface(width:22.5.w,height:9.5.h,left:0.w,top:0.h,),"6:531":PixFlutterInterface(width:20.5.w,height:7.5.h,left:1.w,top:1.h,),"6:532":PixFlutterInterface(width:1.5.w,height:3.5.h,left:23.w,top:3.h,),"6:544":PixFlutterInterface(width:5.5.w,height:5.5.w,left:28.w,top:0.h,),"6:545":PixFlutterInterface(width:4.5.w,height:4.5.w,left:0.5.w,top:0.5.h,),"6:546":PixFlutterInterface(width:5.5.w,height:5.5.w,left:0.w,top:0.h,),"6:547":PixFlutterInterface(width:5.5.w,height:5.5.w,left:21.w,top:0.h,),"6:548":PixFlutterInterface(width:5.5.w,height:5.5.w,left:14.w,top:0.h,),"6:549":PixFlutterInterface(width:5.5.w,height:5.5.w,left:7.w,top:0.h,),"6:550":PixFlutterInterface(width:5.5.w,height:5.5.w,left:0.w,top:0.h,),}, false),
                  ],),),
              ],
            )
          )
        
      ),
      
      
    );
  }
}
