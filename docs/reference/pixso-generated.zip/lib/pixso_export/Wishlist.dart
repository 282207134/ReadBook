import 'package:flutter/material.dart';
import 'package:flutter_ui/utils/pix_adapted_screen.dart';
import 'package:flutter_ui/custom_widget/CustomWidget_34_156.dart';
import 'package:flutter_ui/components/Group.dart';
import 'package:flutter_ui/utils/pix_flutter_interface.dart';

class Wishlist extends StatefulWidget {

  Wishlist({super.key,});
  @override
  State<Wishlist> createState() => _WishlistState();
}

class _WishlistState extends State<Wishlist> {


  @override
  void initState() {
    super.initState();
  
  }


  @override
  Widget build(BuildContext context) {
    ScreenUtil().rootSize = Size(375, 667);
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: MediaQuery.removePadding(
        context: context,
        removeTop: true,
        removeBottom: true,
        child: SizedBox(
            width: 375.w,
            height: 667.h,
            child: ListView(
              children: [
                Container(
                width: 375.w,
                height: 667.h,
                decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                clipBehavior: Clip.hardEdge,
                child: Stack(
                  key: ValueKey("34:12"),
                  children: [
                    Positioned(
                      width: 375.w,
                      height: 152.h,
                      left: 0.w,
                      top: 368.h,
                      child: Container(
                        key: ValueKey("95:50"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, 0.w),blurRadius: 5.w,)],),),),
                    Positioned(
                      width: 375.w,
                      height: 64.h,
                      left: 0.w,
                      top: 0.h,
                      child: Container(
                        key: ValueKey("34:14"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, -1.w),blurRadius: 10.w,)],),),),
                    Positioned(
                      width: 65.w,
                      height: 23.h,
                      left: 155.w,
                      top: 29.h,
                      child: Text("Wishlist",
                        key: ValueKey("34:15"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 17.6.sp, letterSpacing: 0.w),),),
                    CustomWidget_34_156(),
                    Positioned(
                      width: 24.w,
                      height: 2.h,
                      left: 175.w,
                      top: 665.h,
                      child: Container(
                        key: ValueKey("36:150"),
                        decoration: BoxDecoration(color: Color.fromRGBO(50, 205, 119,1),border: Border.all(width: 1.w, color: Colors.transparent, ),),),),
                    Positioned(
                      width: 343.w,
                      height: 46.h,
                      left: 16.w,
                      top: 555.h,
                      child: Container(
                        key: ValueKey("51:11"),
                        decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment(0,0), end: Alignment(1.0000000291545188,1.0000000217391303), colors: [Color.fromRGBO(129, 251, 184,1), Color.fromRGBO(40, 199, 111,1)], stops: [0, 1]),borderRadius: BorderRadius.circular(4.h),border: Border.all(width: 1.w, color: Colors.transparent, ),),),),
                    Positioned(
                      width: 82.w,
                      height: 20.h,
                      left: 147.w,
                      top: 568.h,
                      child: Text("Add to Cart",
                        key: ValueKey("51:12"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(255, 255, 255,1), fontFamily: "Circular Std", fontWeight: FontWeight.bold, fontSize: 14.6.sp, height: 1.3333333333333333, letterSpacing: 0.w),),),
                    Positioned(
                      width: 375.w,
                      height: 152.h,
                      left: 0.w,
                      top: 216.h,
                      child: Container(
                        key: ValueKey("95:2"),
                        decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, 0.w),blurRadius: 5.w,)],),),),
                    Positioned(
                      width: 72.w,
                      height: 112.h,
                      left: 16.w,
                      top: 84.h,
                      child: Container(
                        clipBehavior: Clip.hardEdge,
                        decoration: BoxDecoration(),
                        child: Image(
                          key: ValueKey("95:3"),
                          image: AssetImage("http://localhost:3667/assets/1793182110309/MaskGroup.png.png"),),),),
                    Positioned(
                      width: 144.w,
                      height: 18.h,
                      left: 104.w,
                      top: 114.h,
                      child: Text("Motion Design for Film",
                        key: ValueKey("95:7"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.2857142857142858, letterSpacing: 0.w),),),
                    Positioned(
                      width: 94.w,
                      height: 16.h,
                      left: 104.w,
                      top: 136.h,
                      child: Text("by Steven Curran",
                        key: ValueKey("95:8"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(167, 167, 177,1), fontFamily: "Circular Std", fontSize: 11.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 104.w,
                      top: 96.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("95:9"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("95:10"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group11.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 118.w,
                      top: 96.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("95:12"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("95:13"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group10.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 132.w,
                      top: 96.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("95:15"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("95:16"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group9.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 146.w,
                      top: 96.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("95:18"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("95:19"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group8.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 160.w,
                      top: 96.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("95:21"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("95:22"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group7.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 42.w,
                      height: 18.h,
                      left: 317.w,
                      top: 93.h,
                      child: Text("\$10.55",
                        key: ValueKey("95:24"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(50, 205, 119,1), fontFamily: "Circular Std", fontWeight: FontWeight.bold, fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 72.w,
                      height: 112.h,
                      left: 16.w,
                      top: 236.h,
                      child: Container(
                        clipBehavior: Clip.hardEdge,
                        decoration: BoxDecoration(),
                        child: Image(
                          key: ValueKey("95:26"),
                          image: AssetImage("http://localhost:3667/assets/1793182110309/MaskGroup.png.png"),),),),
                    Positioned(
                      width: 114.w,
                      height: 18.h,
                      left: 104.w,
                      top: 266.h,
                      child: Text("How to Stop Time",
                        key: ValueKey("95:30"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.2857142857142858, letterSpacing: 0.w),),),
                    Positioned(
                      width: 94.w,
                      height: 16.h,
                      left: 104.w,
                      top: 288.h,
                      child: Text("by Steven Curran",
                        key: ValueKey("95:31"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(167, 167, 177,1), fontFamily: "Circular Std", fontSize: 11.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 104.w,
                      top: 248.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("95:32"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("95:33"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group4.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 118.w,
                      top: 248.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("95:35"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("95:36"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group3.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 132.w,
                      top: 248.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("95:38"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("95:39"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group2.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 146.w,
                      top: 248.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("95:41"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("95:42"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group6.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 160.w,
                      top: 248.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("95:44"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("95:45"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group5.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 41.w,
                      height: 18.h,
                      left: 318.w,
                      top: 245.h,
                      child: Text("\$20.12",
                        key: ValueKey("95:47"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(50, 205, 119,1), fontFamily: "Circular Std", fontWeight: FontWeight.bold, fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 51.w,
                      height: 16.h,
                      left: 104.w,
                      top: 328.h,
                      child: Text("remove".toUpperCase(),
                        key: ValueKey("95:48"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(3, 150, 255,1), fontFamily: "Circular Std", fontWeight: FontWeight.w500, fontSize: 11.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 51.w,
                      height: 16.h,
                      left: 104.w,
                      top: 480.h,
                      child: Text("remove".toUpperCase(),
                        key: ValueKey("95:293"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(3, 150, 255,1), fontFamily: "Circular Std", fontWeight: FontWeight.w500, fontSize: 11.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 51.w,
                      height: 16.h,
                      left: 104.w,
                      top: 176.h,
                      child: Text("remove".toUpperCase(),
                        key: ValueKey("95:49"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(3, 150, 255,1), fontFamily: "Circular Std", fontWeight: FontWeight.w500, fontSize: 11.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 72.w,
                      height: 112.h,
                      left: 16.w,
                      top: 388.h,
                      child: Container(
                        clipBehavior: Clip.hardEdge,
                        decoration: BoxDecoration(),
                        child: Image(
                          key: ValueKey("95:51"),
                          image: AssetImage("http://localhost:3667/assets/1793182110309/MaskGroup.png.png"),),),),
                    Positioned(
                      width: 140.w,
                      height: 18.h,
                      left: 104.w,
                      top: 418.h,
                      child: Text("Hardwiring Happiness",
                        key: ValueKey("95:55"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.2857142857142858, letterSpacing: 0.w),),),
                    Positioned(
                      width: 94.w,
                      height: 16.h,
                      left: 104.w,
                      top: 440.h,
                      child: Text("by Steven Curran",
                        key: ValueKey("95:56"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(167, 167, 177,1), fontFamily: "Circular Std", fontSize: 11.6.sp, letterSpacing: 0.w),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 104.w,
                      top: 400.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("95:57"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("95:58"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group21.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 118.w,
                      top: 400.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("95:60"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("95:61"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group20.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 132.w,
                      top: 400.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("95:63"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("95:64"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group19.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 146.w,
                      top: 400.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("95:66"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("95:67"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group18.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 12.w,
                      height: 11.44.h,
                      left: 160.w,
                      top: 400.h,
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                        clipBehavior: Clip.hardEdge,
                        child: Stack(
                          key: ValueKey("95:69"),
                          children: [
                            Positioned(
                              width: 12.w,
                              height: 11.44.h,
                              left: 0.w,
                              top: 0.h,
                              child: Container(
                                clipBehavior: Clip.hardEdge,
                                decoration: BoxDecoration(),
                                child: Image(
                                  key: ValueKey("95:70"),
                                  image: AssetImage("http://localhost:3667/assets/1793182110309/Group17.svg.png"),),),),
                          ],),),),
                    Positioned(
                      width: 39.w,
                      height: 18.h,
                      left: 320.w,
                      top: 397.h,
                      child: Text("\$17.25",
                        key: ValueKey("95:72"),
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Color.fromRGBO(50, 205, 119,1), fontFamily: "Circular Std", fontWeight: FontWeight.bold, fontSize: 13.6.sp, letterSpacing: 0.w),),),
                    Group({"6:525":PixFlutterInterface(width:31.w,height:16.h,left:304.5.w,top:0.h,),"6:526":PixFlutterInterface(width:24.5.w,height:9.5.h,left:338.5.w,top:3.5.h,),"6:527":PixFlutterInterface(width:22.5.w,height:9.5.h,left:0.w,top:0.h,),"6:528":PixFlutterInterface(width:22.5.w,height:9.5.h,left:0.w,top:0.h,),"6:529":PixFlutterInterface(width:21.5.w,height:8.5.h,left:0.5.w,top:0.5.h,),"6:530":PixFlutterInterface(width:22.5.w,height:9.5.h,left:0.w,top:0.h,),"6:531":PixFlutterInterface(width:20.5.w,height:7.5.h,left:1.w,top:1.h,),"6:532":PixFlutterInterface(width:1.5.w,height:3.5.h,left:23.w,top:3.h,),"6:542":PixFlutterInterface(width:48.w,height:16.h,left:157.w,top:1.h,),"6:543":PixFlutterInterface(width:33.5.w,height:5.5.h,left:0.w,top:5.5.h,),"6:544":PixFlutterInterface(width:5.5.w,height:5.5.w,left:28.w,top:0.h,),"6:545":PixFlutterInterface(width:4.5.w,height:4.5.w,left:0.5.w,top:0.5.h,),"6:546":PixFlutterInterface(width:5.5.w,height:5.5.w,left:0.w,top:0.h,),"6:547":PixFlutterInterface(width:5.5.w,height:5.5.w,left:21.w,top:0.h,),"6:548":PixFlutterInterface(width:5.5.w,height:5.5.w,left:14.w,top:0.h,),"6:549":PixFlutterInterface(width:5.5.w,height:5.5.w,left:7.w,top:0.h,),"6:550":PixFlutterInterface(width:5.5.w,height:5.5.w,left:0.w,top:0.h,),"96:52":PixFlutterInterface(width:363.w,height:17.h,left:6.5.w,top:2.h,),}, false),
                  ],),),
              ],
            )
          )
        
      ),
      
      
    );
  }
}
