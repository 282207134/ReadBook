import 'package:flutter/material.dart';
import 'package:flutter_ui/utils/pix_adapted_screen.dart';

class CustomWidget_14_107 extends StatelessWidget {
 CustomWidget_14_107({super.key});
  
  @override
  Widget build(BuildContext context) {
    return Positioned(
          width: 58.w,
          height: 9.53.h,
          left: 68.w,
          top: 1064.h,
          child: Container(
            decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
            clipBehavior: Clip.hardEdge,
            child: Stack(
              key: ValueKey("14:107"),
              children: [
                Positioned(
                  width: 10.w,
                  height: 9.53.h,
                  left: 0.w,
                  top: 0.h,
                  child: Container(
                    decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                    clipBehavior: Clip.hardEdge,
                    child: Stack(
                      key: ValueKey("14:92"),
                      children: [
                        Positioned(
                          width: 10.w,
                          height: 9.53.h,
                          left: 0.w,
                          top: 0.h,
                          child: Container(
                            clipBehavior: Clip.hardEdge,
                            decoration: BoxDecoration(),
                            child: Image(
                              key: ValueKey("14:93"),
                              image: AssetImage("http://localhost:3667/assets/1793182110309/Group84.svg.png"),),),),
                      ],),),),
                Positioned(
                  width: 10.w,
                  height: 9.53.h,
                  left: 12.w,
                  top: 0.h,
                  child: Container(
                    decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                    clipBehavior: Clip.hardEdge,
                    child: Stack(
                      key: ValueKey("14:95"),
                      children: [
                        Positioned(
                          width: 10.w,
                          height: 9.53.h,
                          left: 0.w,
                          top: 0.h,
                          child: Container(
                            clipBehavior: Clip.hardEdge,
                            decoration: BoxDecoration(),
                            child: Image(
                              key: ValueKey("14:96"),
                              image: AssetImage("http://localhost:3667/assets/1793182110309/Group83.svg.png"),),),),
                      ],),),),
                Positioned(
                  width: 10.w,
                  height: 9.53.h,
                  left: 24.w,
                  top: 0.h,
                  child: Container(
                    decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                    clipBehavior: Clip.hardEdge,
                    child: Stack(
                      key: ValueKey("14:98"),
                      children: [
                        Positioned(
                          width: 10.w,
                          height: 9.53.h,
                          left: 0.w,
                          top: 0.h,
                          child: Container(
                            clipBehavior: Clip.hardEdge,
                            decoration: BoxDecoration(),
                            child: Image(
                              key: ValueKey("14:99"),
                              image: AssetImage("http://localhost:3667/assets/1793182110309/Group82.svg.png"),),),),
                      ],),),),
                Positioned(
                  width: 10.w,
                  height: 9.53.h,
                  left: 36.w,
                  top: 0.h,
                  child: Container(
                    decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                    clipBehavior: Clip.hardEdge,
                    child: Stack(
                      key: ValueKey("14:101"),
                      children: [
                        Positioned(
                          width: 10.w,
                          height: 9.53.h,
                          left: 0.w,
                          top: 0.h,
                          child: Container(
                            clipBehavior: Clip.hardEdge,
                            decoration: BoxDecoration(),
                            child: Image(
                              key: ValueKey("14:102"),
                              image: AssetImage("http://localhost:3667/assets/1793182110309/Group80.svg.png"),),),),
                      ],),),),
                Positioned(
                  width: 10.w,
                  height: 9.53.h,
                  left: 48.w,
                  top: 0.h,
                  child: Container(
                    decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                    clipBehavior: Clip.hardEdge,
                    child: Stack(
                      key: ValueKey("14:104"),
                      children: [
                        Positioned(
                          width: 10.w,
                          height: 9.53.h,
                          left: 0.w,
                          top: 0.h,
                          child: Container(
                            clipBehavior: Clip.hardEdge,
                            decoration: BoxDecoration(),
                            child: Image(
                              key: ValueKey("14:105"),
                              image: AssetImage("http://localhost:3667/assets/1793182110309/Group81.svg.png"),),),),
                      ],),),),
              ],),),);
  }
}
