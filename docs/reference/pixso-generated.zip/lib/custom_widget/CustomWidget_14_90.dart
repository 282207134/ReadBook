import 'package:flutter/material.dart';
import 'package:flutter_ui/utils/pix_adapted_screen.dart';
import 'package:flutter_ui/custom_widget/CustomWidget_14_107.dart';
import 'package:flutter_ui/utils/pix_text_rich.dart';
import 'package:flutter_ui/custom_widget/CustomWidget_5_94.dart';
import 'package:flutter_ui/custom_widget/CustomWidget_14_116.dart';

class CustomWidget_14_90 extends StatelessWidget {
 CustomWidget_14_90({super.key});
  
  @override
  Widget build(BuildContext context) {
    return Positioned(
          width: 165.w,
          height: 18.h,
          left: 105.w,
          top: 458.h,
          child: Container(
            decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
            clipBehavior: Clip.hardEdge,
            child: Stack(
              key: ValueKey("14:90"),
              children: [
                Positioned(
                  width: 71.w,
                  height: 18.h,
                  left: 94.w,
                  top: 0.h,
                  child: Text("38 Reviews",
                    key: ValueKey("14:89"),
                    textAlign: TextAlign.left,
                    style: TextStyle(color: Color.fromRGBO(3, 150, 255,1), fontFamily: "Circular Std", fontSize: 13.6.sp, letterSpacing: 0.w),),),
                Positioned(
                  width: 86.w,
                  height: 13.35.h,
                  left: 0.w,
                  top: 2.h,
                  child: Container(
                    decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                    clipBehavior: Clip.hardEdge,
                    child: Stack(
                      key: ValueKey("14:88"),
                      children: [
                        Positioned(
                          width: 14.w,
                          height: 13.35.h,
                          left: 0.w,
                          top: 0.h,
                          child: Container(
                            decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                            clipBehavior: Clip.hardEdge,
                            child: Stack(
                              key: ValueKey("14:70"),
                              children: [
                                Positioned(
                                  width: 14.w,
                                  height: 13.35.h,
                                  left: 0.w,
                                  top: 0.h,
                                  child: Container(
                                    clipBehavior: Clip.hardEdge,
                                    decoration: BoxDecoration(),
                                    child: Image(
                                      key: ValueKey("14:71"),
                                      image: AssetImage("http://localhost:3667/assets/1793182110309/Group89.svg.png"),),),),
                              ],),),),
                        Positioned(
                          width: 14.w,
                          height: 13.35.h,
                          left: 18.w,
                          top: 0.h,
                          child: Container(
                            decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                            clipBehavior: Clip.hardEdge,
                            child: Stack(
                              key: ValueKey("14:73"),
                              children: [
                                Positioned(
                                  width: 14.w,
                                  height: 13.35.h,
                                  left: 0.w,
                                  top: 0.h,
                                  child: Container(
                                    clipBehavior: Clip.hardEdge,
                                    decoration: BoxDecoration(),
                                    child: Image(
                                      key: ValueKey("14:74"),
                                      image: AssetImage("http://localhost:3667/assets/1793182110309/Group88.svg.png"),),),),
                              ],),),),
                        Positioned(
                          width: 14.w,
                          height: 13.35.h,
                          left: 36.w,
                          top: 0.h,
                          child: Container(
                            decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                            clipBehavior: Clip.hardEdge,
                            child: Stack(
                              key: ValueKey("14:76"),
                              children: [
                                Positioned(
                                  width: 14.w,
                                  height: 13.35.h,
                                  left: 0.w,
                                  top: 0.h,
                                  child: Container(
                                    clipBehavior: Clip.hardEdge,
                                    decoration: BoxDecoration(),
                                    child: Image(
                                      key: ValueKey("14:77"),
                                      image: AssetImage("http://localhost:3667/assets/1793182110309/Group87.svg.png"),),),),
                              ],),),),
                        Positioned(
                          width: 14.w,
                          height: 13.35.h,
                          left: 54.w,
                          top: 0.h,
                          child: Container(
                            decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                            clipBehavior: Clip.hardEdge,
                            child: Stack(
                              key: ValueKey("14:79"),
                              children: [
                                Positioned(
                                  width: 14.w,
                                  height: 13.35.h,
                                  left: 0.w,
                                  top: 0.h,
                                  child: Container(
                                    clipBehavior: Clip.hardEdge,
                                    decoration: BoxDecoration(),
                                    child: Image(
                                      key: ValueKey("14:80"),
                                      image: AssetImage("http://localhost:3667/assets/1793182110309/Group85.svg.png"),),),),
                              ],),),),
                        Positioned(
                          width: 14.w,
                          height: 13.35.h,
                          left: 72.w,
                          top: 0.h,
                          child: Container(
                            decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                            clipBehavior: Clip.hardEdge,
                            child: Stack(
                              key: ValueKey("14:82"),
                              children: [
                                Positioned(
                                  width: 14.w,
                                  height: 13.35.h,
                                  left: 0.w,
                                  top: 0.h,
                                  child: Container(
                                    clipBehavior: Clip.hardEdge,
                                    decoration: BoxDecoration(),
                                    child: Image(
                                      key: ValueKey("14:83"),
                                      image: AssetImage("http://localhost:3667/assets/1793182110309/Group86.svg.png"),),),),
                              ],),),),
                      ],),),),
              ],),),);
  }
}
