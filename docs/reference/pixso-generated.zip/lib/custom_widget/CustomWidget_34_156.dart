import 'package:flutter/material.dart';
import 'package:flutter_ui/utils/pix_adapted_screen.dart';

class CustomWidget_34_156 extends StatelessWidget {
 CustomWidget_34_156({super.key});
  
  @override
  Widget build(BuildContext context) {
    return Positioned(
          width: 375.w,
          height: 50.h,
          left: 0.w,
          top: 617.h,
          child: Container(
            decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
            clipBehavior: Clip.hardEdge,
            child: Stack(
              key: ValueKey("34:156"),
              children: [
                Positioned(
                  width: 375.w,
                  height: 50.h,
                  left: 0.w,
                  top: 0.h,
                  child: Container(
                    key: ValueKey("34:74"),
                    decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, 1.w),blurRadius: 10.w,)],),),),
                Positioned(
                  width: 22.w,
                  height: 23.h,
                  left: 27.w,
                  top: 13.h,
                  child: Container(
                    decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                    clipBehavior: Clip.hardEdge,
                    child: Stack(
                      key: ValueKey("34:75"),
                      children: [
                        Positioned(
                          width: 23.w,
                          height: 24.12.h,
                          left: 0.w,
                          top: 0.h,
                          child: Container(
                            clipBehavior: Clip.hardEdge,
                            decoration: BoxDecoration(),
                            child: Image(
                              key: ValueKey("34:76"),
                              image: AssetImage("http://localhost:3667/assets/1793182110309/Group16.svg.png"),),),),
                      ],),),),
                Positioned(
                  width: 23.w,
                  height: 20.37.h,
                  left: 176.w,
                  top: 16.h,
                  child: Container(
                    decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                    clipBehavior: Clip.hardEdge,
                    child: Stack(
                      key: ValueKey("34:78"),
                      children: [
                        Positioned(
                          width: 25.w,
                          height: 22.78.h,
                          left: 0.w,
                          top: 0.h,
                          child: Container(
                            clipBehavior: Clip.hardEdge,
                            decoration: BoxDecoration(),
                            child: Image(
                              key: ValueKey("34:79"),
                              image: AssetImage("http://localhost:3667/assets/1793182110309/Group14.svg.png"),),),),
                      ],),),),
                Positioned(
                  width: 22.w,
                  height: 22.h,
                  left: 102.w,
                  top: 14.h,
                  child: Container(
                    decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                    clipBehavior: Clip.hardEdge,
                    child: Stack(
                      key: ValueKey("34:81"),
                      children: [
                        Positioned(
                          width: 22.85.w,
                          height: 22.85.h,
                          left: 0.w,
                          top: 0.h,
                          child: Container(
                            clipBehavior: Clip.hardEdge,
                            decoration: BoxDecoration(),
                            child: Image(
                              key: ValueKey("34:82"),
                              image: AssetImage("http://localhost:3667/assets/1793182110309/Group12.svg.png"),),),),
                      ],),),),
                Positioned(
                  width: 22.w,
                  height: 22.h,
                  left: 252.w,
                  top: 14.h,
                  child: Container(
                    decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                    clipBehavior: Clip.hardEdge,
                    child: Stack(
                      key: ValueKey("34:85"),
                      children: [
                        Positioned(
                          width: 23.w,
                          height: 23.h,
                          left: 0.w,
                          top: 0.h,
                          child: Container(
                            clipBehavior: Clip.hardEdge,
                            decoration: BoxDecoration(),
                            child: Image(
                              key: ValueKey("34:86"),
                              image: AssetImage("http://localhost:3667/assets/1793182110309/Group13.svg.png"),),),),
                      ],),),),
                Positioned(
                  width: 22.w,
                  height: 23.57.h,
                  left: 327.w,
                  top: 13.h,
                  child: Container(
                    decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                    clipBehavior: Clip.hardEdge,
                    child: Stack(
                      key: ValueKey("34:89"),
                      children: [
                        Positioned(
                          width: 23.w,
                          height: 24.57.h,
                          left: 0.w,
                          top: 0.h,
                          child: Container(
                            clipBehavior: Clip.hardEdge,
                            decoration: BoxDecoration(),
                            child: Image(
                              key: ValueKey("34:90"),
                              image: AssetImage("http://localhost:3667/assets/1793182110309/Group15.svg.png"),),),),
                      ],),),),
              ],),),);
  }
}
