import 'package:flutter/material.dart';
import 'package:flutter_ui/utils/pix_adapted_screen.dart';
import 'package:flutter_ui/custom_widget/CustomWidget_14_107.dart';
import 'package:flutter_ui/utils/pix_text_rich.dart';
import 'package:flutter_ui/custom_widget/CustomWidget_5_94.dart';

class CustomWidget_14_116 extends StatelessWidget {
 CustomWidget_14_116({super.key});
  
  @override
  Widget build(BuildContext context) {
    return Positioned(
          width: 58.w,
          height: 9.53.h,
          left: 68.w,
          top: 1222.h,
          child: Container(
            decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
            clipBehavior: Clip.hardEdge,
            child: Stack(
              key: ValueKey("14:116"),
              children: [
                Positioned(
                  width: 10.w,
                  height: 9.53.h,
                  left: 0.w,
                  top: 0.h,
                  child: Container(
                    decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                    clipBehavior: Clip.hardEdge,
                    child: Stack(
                      key: ValueKey("14:117"),
                      children: [
                        Positioned(
                          width: 10.w,
                          height: 9.53.h,
                          left: 0.w,
                          top: 0.h,
                          child: Container(
                            clipBehavior: Clip.hardEdge,
                            decoration: BoxDecoration(),
                            child: Image(
                              key: ValueKey("14:118"),
                              image: AssetImage("http://localhost:3667/assets/1793182110309/Group94.svg.png"),),),),
                      ],),),),
                Positioned(
                  width: 10.w,
                  height: 9.53.h,
                  left: 12.w,
                  top: 0.h,
                  child: Container(
                    decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                    clipBehavior: Clip.hardEdge,
                    child: Stack(
                      key: ValueKey("14:120"),
                      children: [
                        Positioned(
                          width: 10.w,
                          height: 9.53.h,
                          left: 0.w,
                          top: 0.h,
                          child: Container(
                            clipBehavior: Clip.hardEdge,
                            decoration: BoxDecoration(),
                            child: Image(
                              key: ValueKey("14:121"),
                              image: AssetImage("http://localhost:3667/assets/1793182110309/Group93.svg.png"),),),),
                      ],),),),
                Positioned(
                  width: 10.w,
                  height: 9.53.h,
                  left: 24.w,
                  top: 0.h,
                  child: Container(
                    decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                    clipBehavior: Clip.hardEdge,
                    child: Stack(
                      key: ValueKey("14:123"),
                      children: [
                        Positioned(
                          width: 10.w,
                          height: 9.53.h,
                          left: 0.w,
                          top: 0.h,
                          child: Container(
                            clipBehavior: Clip.hardEdge,
                            decoration: BoxDecoration(),
                            child: Image(
                              key: ValueKey("14:124"),
                              image: AssetImage("http://localhost:3667/assets/1793182110309/Group92.svg.png"),),),),
                      ],),),),
                Positioned(
                  width: 10.w,
                  height: 9.53.h,
                  left: 36.w,
                  top: 0.h,
                  child: Container(
                    decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                    clipBehavior: Clip.hardEdge,
                    child: Stack(
                      key: ValueKey("14:126"),
                      children: [
                        Positioned(
                          width: 10.w,
                          height: 9.53.h,
                          left: 0.w,
                          top: 0.h,
                          child: Container(
                            clipBehavior: Clip.hardEdge,
                            decoration: BoxDecoration(),
                            child: Image(
                              key: ValueKey("14:127"),
                              image: AssetImage("http://localhost:3667/assets/1793182110309/Group90.svg.png"),),),),
                      ],),),),
                Positioned(
                  width: 10.w,
                  height: 9.53.h,
                  left: 48.w,
                  top: 0.h,
                  child: Container(
                    decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                    clipBehavior: Clip.hardEdge,
                    child: Stack(
                      key: ValueKey("14:129"),
                      children: [
                        Positioned(
                          width: 10.w,
                          height: 9.53.h,
                          left: 0.w,
                          top: 0.h,
                          child: Container(
                            clipBehavior: Clip.hardEdge,
                            decoration: BoxDecoration(),
                            child: Image(
                              key: ValueKey("14:130"),
                              image: AssetImage("http://localhost:3667/assets/1793182110309/Group91.svg.png"),),),),
                      ],),),),
              ],),),);
  }
}
