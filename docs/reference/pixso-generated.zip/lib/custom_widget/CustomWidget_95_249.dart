import 'package:flutter/material.dart';
import 'package:flutter_ui/utils/pix_adapted_screen.dart';

class CustomWidget_95_249 extends StatelessWidget {
 CustomWidget_95_249({super.key});
  
  @override
  Widget build(BuildContext context) {
    return Positioned(
          width: 375.w,
          height: 50.h,
          left: 0.w,
          top: 907.h,
          child: Container(
            decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
            clipBehavior: Clip.hardEdge,
            child: Stack(
              key: ValueKey("95:249"),
              children: [
                Positioned(
                  width: 375.w,
                  height: 50.h,
                  left: 0.w,
                  top: 0.h,
                  child: Container(
                    key: ValueKey("14:0"),
                    decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255,1),border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0,0.1),offset: Offset(0.w, 1.w),blurRadius: 10.w,)],),),),
                Positioned(
                  width: 22.w,
                  height: 23.h,
                  left: 27.w,
                  top: 13.h,
                  child: Container(
                    decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),boxShadow: [BoxShadow(color: Color.fromRGBO(129, 251, 184,0.4),offset: Offset(0.w, 0.w),blurRadius: 20.w,)],),
                    clipBehavior: Clip.hardEdge,
                    child: Stack(
                      key: ValueKey("14:1"),
                      children: [
                        Positioned(
                          width: 22.w,
                          height: 23.h,
                          left: 0.w,
                          top: 0.h,
                          child: Container(
                            clipBehavior: Clip.hardEdge,
                            decoration: BoxDecoration(),
                            child: Image(
                              key: ValueKey("14:2"),
                              image: AssetImage("http://localhost:3667/assets/1793182110309/Group72.svg.png"),),),),
                      ],),),),
                Positioned(
                  width: 23.w,
                  height: 20.37.h,
                  left: 176.w,
                  top: 16.h,
                  child: Container(
                    decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                    clipBehavior: Clip.hardEdge,
                    child: Stack(
                      key: ValueKey("14:4"),
                      children: [
                        Positioned(
                          width: 24.w,
                          height: 21.58.h,
                          left: 0.w,
                          top: 0.h,
                          child: Container(
                            clipBehavior: Clip.hardEdge,
                            decoration: BoxDecoration(),
                            child: Image(
                              key: ValueKey("14:5"),
                              image: AssetImage("http://localhost:3667/assets/1793182110309/Group70.svg.png"),),),),
                      ],),),),
                Positioned(
                  width: 22.w,
                  height: 22.h,
                  left: 102.w,
                  top: 14.h,
                  child: Container(
                    decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                    clipBehavior: Clip.hardEdge,
                    child: Stack(
                      key: ValueKey("14:7"),
                      children: [
                        Positioned(
                          width: 22.85.w,
                          height: 22.85.h,
                          left: 0.w,
                          top: 0.h,
                          child: Container(
                            clipBehavior: Clip.hardEdge,
                            decoration: BoxDecoration(),
                            child: Image(
                              key: ValueKey("14:8"),
                              image: AssetImage("http://localhost:3667/assets/1793182110309/Group68.svg.png"),),),),
                      ],),),),
                Positioned(
                  width: 22.w,
                  height: 22.h,
                  left: 252.w,
                  top: 14.h,
                  child: Container(
                    decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                    clipBehavior: Clip.hardEdge,
                    child: Stack(
                      key: ValueKey("14:11"),
                      children: [
                        Positioned(
                          width: 23.w,
                          height: 23.h,
                          left: 0.w,
                          top: 0.h,
                          child: Container(
                            clipBehavior: Clip.hardEdge,
                            decoration: BoxDecoration(),
                            child: Image(
                              key: ValueKey("14:12"),
                              image: AssetImage("http://localhost:3667/assets/1793182110309/Group69.svg.png"),),),),
                      ],),),),
                Positioned(
                  width: 22.w,
                  height: 23.57.h,
                  left: 327.w,
                  top: 13.h,
                  child: Container(
                    decoration: BoxDecoration(border: Border.all(width: 1.w, color: Colors.transparent, ),),
                    clipBehavior: Clip.hardEdge,
                    child: Stack(
                      key: ValueKey("14:15"),
                      children: [
                        Positioned(
                          width: 23.w,
                          height: 24.57.h,
                          left: 0.w,
                          top: 0.h,
                          child: Container(
                            clipBehavior: Clip.hardEdge,
                            decoration: BoxDecoration(),
                            child: Image(
                              key: ValueKey("14:16"),
                              image: AssetImage("http://localhost:3667/assets/1793182110309/Group71.svg.png"),),),),
                      ],),),),
                Positioned(
                  width: 24.w,
                  height: 2.h,
                  left: 26.w,
                  top: 48.h,
                  child: Container(
                    key: ValueKey("36:148"),
                    decoration: BoxDecoration(color: Color.fromRGBO(50, 205, 119,1),border: Border.all(width: 1.w, color: Colors.transparent, ),),),),
              ],),),);
  }
}
