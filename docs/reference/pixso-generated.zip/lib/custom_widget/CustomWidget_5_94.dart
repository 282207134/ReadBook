import 'package:flutter/material.dart';
import 'package:flutter_ui/utils/pix_adapted_screen.dart';
import 'package:flutter_ui/custom_widget/CustomWidget_14_107.dart';
import 'package:flutter_ui/utils/pix_text_rich.dart';

class CustomWidget_5_94 extends StatelessWidget {
 CustomWidget_5_94({super.key});
  
  @override
  Widget build(BuildContext context) {
    return Positioned(
          width: 343.w,
          height: 200.h,
          left: 15.w,
          top: 780.h,
          child: PixTextRich(
            textAlign: TextAlign.left,
            style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.7142857142857142, letterSpacing: 0.w),
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              PixTextItem(
                margin: EdgeInsets.only(top: 0.h),
                key: ValueKey("5:94_0"),
                children: [
                  TextSpan(
                    text: "Format: ",
                    style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.7142857142857142),),
                  TextSpan(
                    text: "Hardback | 320 pages",
                    style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontWeight: FontWeight.bold, fontSize: 13.6.sp, height: 1.7142857142857142, letterSpacing: 0.w),),
                ],),
              PixTextItem(
                margin: EdgeInsets.only(top: 0.h),
                key: ValueKey("5:94_1"),
                children: [
                  TextSpan(
                    text: "Language: ",
                    style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.7142857142857142),),
                  TextSpan(
                    text: "English",
                    style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontWeight: FontWeight.bold, fontSize: 13.6.sp, height: 1.7142857142857142, letterSpacing: 0.w),),
                ],),
              PixTextItem(
                margin: EdgeInsets.only(top: 0.h),
                key: ValueKey("5:94_2"),
                children: [
                  TextSpan(
                    text: "Dimensions: ",
                    style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.7142857142857142),),
                  TextSpan(
                    text: "202 x 277 x 30mm | 1,396g",
                    style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontWeight: FontWeight.bold, fontSize: 13.6.sp, height: 1.7142857142857142, letterSpacing: 0.w),),
                ],),
              PixTextItem(
                margin: EdgeInsets.only(top: 0.h),
                key: ValueKey("5:94_3"),
                children: [
                  TextSpan(
                    text: "Publication Date: ",
                    style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.7142857142857142),),
                  TextSpan(
                    text: "06 Sep 2018",
                    style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontWeight: FontWeight.bold, fontSize: 13.6.sp, height: 1.7142857142857142, letterSpacing: 0.w),),
                ],),
              PixTextItem(
                margin: EdgeInsets.only(top: 0.h),
                key: ValueKey("5:94_4"),
                children: [
                  TextSpan(
                    text: "Publisher: ",
                    style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.7142857142857142),),
                  TextSpan(
                    text: "Ebury Publishing",
                    style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontWeight: FontWeight.bold, fontSize: 13.6.sp, height: 1.7142857142857142, letterSpacing: 0.w),),
                ],),
              PixTextItem(
                margin: EdgeInsets.only(top: 0.h),
                key: ValueKey("5:94_5"),
                children: [
                  TextSpan(
                    text: "ISBN10: ",
                    style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.7142857142857142),),
                  TextSpan(
                    text: "1785031163",
                    style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontWeight: FontWeight.bold, fontSize: 13.6.sp, height: 1.7142857142857142, letterSpacing: 0.w),),
                ],),
              PixTextItem(
                margin: EdgeInsets.only(top: 0.h),
                key: ValueKey("5:94_6"),
                children: [
                  TextSpan(
                    text: "ISBN13: ",
                    style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontSize: 13.6.sp, height: 1.7142857142857142),),
                  TextSpan(
                    text: "9781785031168",
                    style: TextStyle(color: Color.fromRGBO(100, 100, 117,1), fontFamily: "Circular Std", fontWeight: FontWeight.bold, fontSize: 13.6.sp, height: 1.7142857142857142, letterSpacing: 0.w),),
                ],),
            ],),);
  }
}
